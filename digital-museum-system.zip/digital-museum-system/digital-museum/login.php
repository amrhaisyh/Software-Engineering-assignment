<?php
include "config.php";

if (isset($_POST['submit'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $account_type = $_POST['account_type'];

    // Determine table and redirect page based on account type
    if ($account_type === 'Staff') {
        $table = 'staff';
        $idColumn = 'staffID';
        $redirectPage = 'admin-exhibits.php';
    } else {
        $table = 'admin';
        $idColumn = 'adminID';
        $redirectPage = 'admin-exhibits.php';
    }

    // Prepare and execute SQL query
    $sql = "SELECT * FROM $table WHERE username = ? AND password = ?";
    if ($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "ss", $username, $password);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $_SESSION[$idColumn] = $row[$idColumn];
            $_SESSION['name'] = $row['name'];
            $_SESSION['email'] = $row['email'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['role'] = $account_type;
            $_SESSION['logged_in'] = true;

            // Fetch latest announcement
            $announcementQuery = "SELECT * FROM announcement ORDER BY announcementID DESC";
            $announcementResult = mysqli_query($conn, $announcementQuery);

            if ($announcementResult && mysqli_num_rows($announcementResult) > 0) {
                $announcement = mysqli_fetch_assoc($announcementResult);
                $_SESSION['announcement'] = $announcement;
            }

            echo "<script>alert('Welcome back, {$row['name']}!');</script>";
            echo "<script>window.location.href = '$redirectPage';</script>";
        } else {
            echo "<script>alert('Invalid username or password. Please try again!');</script>";
            echo "<script>window.location.href = 'login.php';</script>";
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "<script>alert('Error in executing SQL query. Please try again later!');</script>";
        echo "<script>window.location.href = 'login.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body>

    <!-- Background SVG -->
    <div class="absolute left-1/2 right-0 top-0 -z-10 -ml-24 transform-gpu overflow-hidden blur-3xl lg:ml-24 xl:ml-48"
        aria-hidden="true">
        <div class="aspect-[801/1036] w-[50.0625rem] bg-gradient-to-tr from-[#89CFF0] to-[#0096FF] opacity-30"
            style="clip-path: polygon(63.1% 29.5%, 100% 17.1%, 76.6% 3%, 48.4% 0%, 44.6% 4.7%, 54.5% 25.3%, 59.8% 49%, 55.2% 57.8%, 44.4% 57.2%, 27.8% 47.9%, 35.1% 81.5%, 0% 97.7%, 39.2% 100%, 35.2% 81.4%, 97.2% 52.8%, 63.1% 29.5%)">
        </div>
    </div>

    <!-- Content -->
    <div class="flex min-h-full flex-col justify-center py-28 sm:px-6 lg:px-8">
        <img class="mx-auto h-[250px] w-auto" src="assets/logo-museum.png" alt="Your Company">

        <div class="mt-10 sm:mx-auto sm:w-full sm:max-w-[480px]">
            <div class="bg-white px-6 py-12 shadow sm:rounded-lg sm:px-12 border border-gray-200">
                <div class="sm:mx-auto sm:w-full sm:max-w-md mb-10">
                    <h2 class="text-2xl font-bold leading-9 tracking-tight text-gray-900">
                        Sign in to your account</h2>
                </div>
                <form class="space-y-6" action="" method="POST">

                    <div class="flex items-center space-x-6">
                        <label class="flex items-center space-x-2 cursor-pointer">
                            <input id="user" name="account_type" type="radio" value="Staff" required
                                class="h-5 w-5 text-indigo-600 border-gray-300 focus:ring-indigo-500">
                            <span class="text-sm text-gray-900 font-medium">Staff</span>
                        </label>

                        <label class="flex items-center space-x-2 cursor-pointer">
                            <input id="staff" name="account_type" type="radio" value="Admin" required
                                class="h-5 w-5 text-indigo-600 border-gray-300 focus:ring-indigo-500">
                            <span class="text-sm text-gray-900 font-medium">Administrator</span>
                        </label>
                    </div>

                    <div>
                        <label for="username" class="block text-sm font-medium leading-6 text-gray-900">Username</label>
                        <div class="mt-2">
                            <input id="text" name="username" type="text" autocomplete="username" required
                                class="block p-2 w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6">
                        </div>
                    </div>

                    <div>
                        <label for="password" class="block text-sm font-medium leading-6 text-gray-900">Password</label>
                        <div class="mt-2">
                            <input id="password" name="password" type="password" autocomplete="current-password"
                                required
                                class="block p-2 w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6">
                        </div>
                    </div>

                    <div>
                        <button type="submit" name="submit"
                            class="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm font-semibold leading-6 text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">Sign
                            in</button>
                    </div>
                </form>
            </div>

            <!-- <p class="mt-10 text-center text-sm text-gray-500">
                Don't have an account?
                <span class="font-semibold leading-6 text-indigo-600 hover:text-indigo-500">Register Here</span>
            </p> -->
        </div>


    </div>
</body>

</html>