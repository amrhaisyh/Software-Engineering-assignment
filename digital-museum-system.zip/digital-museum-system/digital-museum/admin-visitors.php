<?php
include "config.php";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="icon" type="image/png" href="assets/logo-title.jpg" />
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet">
    <title>National Art Museum</title>
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
        }

        .bground-blue {
            background-color: #0097B2;
        }

        .sblue {
            color: #0097B2;
        }

        /* Style the progress bar fill */
        progress::-webkit-progress-value {
            background-color: #0097B2;
            /* Change the fill color to green */
        }
    </style>
</head>

<body class="bg-slate-200">



    <section class="relative">
        <nav class="bg-white flex flex-row gap-x-5 shadow-xl py-3 px-10">
            <div class="flex gap-x-4  ml-5">
                <img style="height: 80px;" src="assets/logo-museum.png" alt="">
                <h1 class="sblue font-bold text-2xl my-auto">National Art Museum</h1>
            </div>
        </nav>
    </section>

    <section class="flex p-10 gap-x-5 h-full">
        <div class="w-[250px]">
            <div class="flex flex-col bg-white p-5 rounded-2xl">
                <svg class="w-20 mx-auto" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                    <path
                        d="M399 384.2C376.9 345.8 335.4 320 288 320H224c-47.4 0-88.9 25.8-111 64.2c35.2 39.2 86.2 63.8 143 63.8s107.8-24.7 143-63.8zM0 256a256 256 0 1 1 512 0A256 256 0 1 1 0 256zm256 16a72 72 0 1 0 0-144 72 72 0 1 0 0 144z" />
                </svg>
                <h1 class="text-lg  text-center mt-5">
                    <?php echo $_SESSION['role']; ?>
                </h1>
                <h1 class="text-sm  text-center">
                    <?php echo $_SESSION['name']; ?>
                </h1>
                <hr class="border-1 border-black my-5">
                <a class="flex mb-4" href="admin-exhibits.php">
                    <div class="w-10 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Exhibit</h1>
                </a>
                <a class="flex mb-4" href="admin-event.php">
                    <div class="w-9 ml-0.5 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Event</h1>
                </a>
                <a class="flex mb-4" href="admin-inquiries.php">
                    <div class="w-9 ml-0.5 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Inquiries</h1>
                </a>
                <a class="flex mb-4 sblue font-semibold" href="admin-visitors.php">
                    <div class="w-9 ml-0.5 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Visitor</h1>
                </a>
                <?php
                if (isset($_SESSION['adminID']) && isset($_SESSION['role']) && $_SESSION['role'] == 'Admin') {
                    echo '
                    <a class="flex mb-4" href="admin-staff.php">
                        <div class="w-9 ml-0.5 mr-auto my-auto"></div>
                        <h1 class="w-full">Staff</h1>
                    </a>';
                }
                ?>
                <a class="flex mb-4" href="admin-feedback.php">
                    <div class="w-9 ml-0.5 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Feedback</h1>
                </a>
                <a class="flex mb-32" href="admin-summary.php">
                    <div class="w-9 ml-1 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Summary</h1>
                </a>
                <hr class="border-1 border-black my-5">
                <a class="flex mb-3" href="admin-profile.php">
                    <div class="w-9 ml-1 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Profile</h1>
                </a>
                <?php
                if (isset($_SESSION['adminID']) && isset($_SESSION['role']) && $_SESSION['role'] == 'Admin') {
                    echo '
                    <a class="flex mb-3" href="admin-access.php">
                        <div class="w-9 ml-1 mr-auto my-auto">
                        </div>
                        <h1 class="w-full">Configuration</h1>
                    </a>
                    ';
                } else {
                    echo '
                    <a class="flex mb-3" href="troubleshoot.php">
                        <div class="w-9 ml-1 mr-auto my-auto">
                        </div>
                        <h1 class="w-full">Troubleshoot</h1>
                    </a>
                    ';
                }
                ?>
                <a class="flex mb-10" href="logout.php">
                    <div class="w-9 ml-1 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Log Out</h1>
                </a>

            </div>

        </div>
        <div class="w-full h-full">
            <div class="bg-white rounded-2xl h-full">
                <!-- Add 'inline-block' class to the image --> <br>
                <span class="font-semibold text-2xl inline-block ml-4 align-middle mb-2">Visitor Details</span><br>
                <!-- Add 'inline-block' class to the span -->
                <hr class="border-gray-300 mb-6">
                <div class=" p-5 ">
                    <table class="w-full mt-5 border-collapse">
                        <thead>
                            <tr class="bg-gray-200">
                                <th class="p-2 text-s">No</th>
                                <th class="p-2 text-s">Name</th>
                                <th class="p-2 text-s">Email</th>
                                <th class="p-2 text-s">username</th>
                                <th class="p-2 text-s">password</th>
                                <th class="p-2 text-s">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- PHP - Fetch Data -->
                            <?php
                            $sql = "SELECT * FROM visitor;";
                            $result = mysqli_query($conn, $sql);

                            $count = 1;
                            if ($result && mysqli_num_rows($result) > 0) {
                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo '
                                    <tr class="bg-white">
                                        <td class="p-2 border text-s text-center">' . $count . '</td>
                                        <td class="p-2 border text-s text-center">' . htmlspecialchars($row['name']) . '</td>
                                        <td class="p-2 border text-s text-center">' . htmlspecialchars($row['email']) . '</td>
                                        <td class="p-2 border text-s text-center">' . htmlspecialchars($row['username']) . '</td>
                                        <td class="p-2 border text-s text-center">
                                            <span id="password_' . $count . '">****</span>
                                            <button onclick="togglePassword(' . $count . ', \'' . addslashes($row['password']) . '\')" class="ml-2 text-blue-500 hover:text-blue-700">
                                                <img src="assets/view.png" alt="View Password" class="w-5 h-5">
                                            </button>
                                        </td>
                                        <td class="p-2 border text-s text-center">
                                            <button class="bg-blue-500 text-white px-4 py-2 rounded" 
                                                onclick="openPopup(
                                                    \'' . $row['visitorID'] . '\', 
                                                    \'' . addslashes($row['name']) . '\', 
                                                    \'' . addslashes($row['email']) . '\', 
                                                    \'' . addslashes($row['password']) . '\'
                                                )">
                                                <span style="font-size:15px">Edit Password</span>
                                            </button>
                                        </td>
                                    </tr>';
                                    $count++;
                                }
                            } else {
                                echo '<tr><td colspan="6" class="text-center">No records found.</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

                <!-- Password Popup Modal -->
                <div id="passwordPopup" class="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center hidden">
                    <div class="bg-white p-5 rounded-xl w-1/3">
                        <h2 class="text-xl font-bold mb-4">Update Password</h2>
                        <hr class="border-1 border-black mb-4">

                        <!-- Form to submit password -->
                        <form id="passwordForm" action="process-password.php" method="POST">
                            <input type="hidden" id="popupVisitorID" name="visitorID">

                            <p class="mb-2"><strong>Name:</strong> <span id="popupName"></span></p>
                            <p class="mb-2"><strong>Email:</strong> <span id="popupEmail"></span></p>
                            <p class="mb-2 font-semibold"><strong>Current Password:</strong> <span id="popupPassword" style="color:red"></span></p>

                            <label class="block mt-4 font-semibold">New Password</label>
                            <input type="password" name="newPassword" class="w-full p-2 border rounded-lg shadow-sm focus:ring-2 focus:ring-blue-400" required>

                            <div class="flex justify-end mt-4">
                                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded shadow-md hover:bg-blue-600 transition duration-200">Save</button>
                                <button type="button" onclick="closePopup()" class="bg-gray-500 text-white px-4 py-2 rounded ml-2">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- JavaScript for Popup Handling -->
                <script>
                    function openPopup(visitorID, name, email, password) {
                        document.getElementById("popupVisitorID").value = visitorID;
                        document.getElementById("popupName").textContent = name;
                        document.getElementById("popupEmail").textContent = email;
                        document.getElementById("popupPassword").textContent = password;

                        document.getElementById("passwordPopup").classList.remove("hidden");
                    }

                    function closePopup() {
                        document.getElementById("passwordPopup").classList.add("hidden");
                    }

                    function togglePassword(id, actualPassword) {
                        var passwordSpan = document.getElementById("password_" + id);
                        if (passwordSpan.textContent === "****") {
                            passwordSpan.textContent = actualPassword; // Show password
                        } else {
                            passwordSpan.textContent = "****"; // Hide password
                        }
                    }
                </script>

            </div>

        </div>

    </section>

</body>

</html>