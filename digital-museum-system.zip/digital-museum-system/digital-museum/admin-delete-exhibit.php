<?php
include "config.php";

$exhibitID = $_GET['id'];

$sql = "DELETE FROM exhibit WHERE exhibitID = '$exhibitID'";

if (mysqli_query($conn, $sql)) {
    mysqli_close($conn);
    echo "<script>alert('The selected Exhibit has been deleted!');</script>";
    echo "<script>window.location.href = 'admin-exhibits.php';</script>";

    exit;
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}
?>
