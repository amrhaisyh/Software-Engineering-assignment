<?php
include "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $staffID = $_POST['staffID'];
    $newPassword = $_POST['newPassword'];

    // Update the password
    $sql = "UPDATE staff SET password = ? WHERE staffID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $newPassword, $staffID);

    if ($stmt->execute()) {
        echo "<script>alert('Password updated successfully!'); window.location.href='admin-staff.php';</script>";
    } else {
        echo "<script>alert('Error updating password. Please try again.'); window.location.href='admin-staff.php';</script>";
    }

    $stmt->close();
    $conn->close();
}
?>