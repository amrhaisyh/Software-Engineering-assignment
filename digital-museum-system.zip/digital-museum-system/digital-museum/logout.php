<?php	
	session_start();
	if(isset($_SESSION['staffID']))
	{
		unset($_SESSION['staffID']);
		unset($_SESSION['name']);
		unset($_SESSION['email']);

	}
	else if(isset($_SESSION['adminID']))
	{
		unset($_SESSION['adminID']);
		unset($_SESSION['name']);
		unset($_SESSION['email']);

	}

	header( "Refresh:1; url=login.php", true, 303);
	session_destroy(); 
?>
