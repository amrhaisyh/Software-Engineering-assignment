<?php
include "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $role = trim($_POST['role']);

    // Validate input (Basic validation)
    if (empty($name) || empty($username) || empty($email) || empty($password) || empty($role)) {
        echo "<script>alert('All fields are required!'); window.history.back();</script>";
        exit();
    }

    // Determine the correct table based on the role
    if ($role == "Visitor") {
        $sql = "INSERT INTO visitor (name, email, username, password) VALUES (?, ?, ?, ?)";
    } elseif ($role == "Staff") {
        $sql = "INSERT INTO staff (name, email, username, password) VALUES (?, ?, ?, ?)";
    } else {
        echo "<script>alert('Invalid role selected!'); window.history.back();</script>";
        exit();
    }

    // Prepare and bind the SQL statement
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $name, $email, $username, $password);

    // Execute and check if the query was successful
    if ($stmt->execute()) {
        echo "<script>alert('User registered successfully!'); window.location.href='admin-access.php';</script>";
    } else {
        echo "<script>alert('Error: " . $stmt->error . "'); window.history.back();</script>";
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo "<script>alert('Invalid request!'); window.history.back();</script>";
}
