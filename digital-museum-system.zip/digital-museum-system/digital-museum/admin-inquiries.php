<?php
include "config.php";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="icon" type="image/png" href="assets/logo-title.jpg" />
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet">
    <title>National Art Museum</title>
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
        }

        .bground-blue {
            background-color: #0097B2;
        }

        .sblue {
            color: #0097B2;
        }

        /* Style the progress bar fill */
        progress::-webkit-progress-value {
            background-color: #0097B2;
            /* Change the fill color to green */
        }
    </style>
</head>

<body class="bg-slate-200">



    <section class="relative">
        <nav class="bg-white flex flex-row gap-x-5 shadow-xl py-3 px-10">
            <div class="flex gap-x-4  ml-5">
                <img style="height: 80px;" src="assets/logo-museum.png" alt="">
                <h1 class="sblue font-bold text-2xl my-auto">National Art Museum</h1>
            </div>
        </nav>
    </section>

    <section class="flex p-10 gap-x-5 h-full">
        <div class="w-[250px]">
            <div class="flex flex-col bg-white p-5 rounded-2xl">
                <svg class="w-20 mx-auto" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                    <path
                        d="M399 384.2C376.9 345.8 335.4 320 288 320H224c-47.4 0-88.9 25.8-111 64.2c35.2 39.2 86.2 63.8 143 63.8s107.8-24.7 143-63.8zM0 256a256 256 0 1 1 512 0A256 256 0 1 1 0 256zm256 16a72 72 0 1 0 0-144 72 72 0 1 0 0 144z" />
                </svg>
                <h1 class="text-lg  text-center mt-5">
                    <?php echo $_SESSION['role']; ?>
                </h1>
                <h1 class="text-sm  text-center">
                    <?php echo $_SESSION['name']; ?>
                </h1>
                <hr class="border-1 border-black my-5">
                <a class="flex mb-4" href="admin-exhibits.php">
                    <div class="w-10 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Exhibit</h1>
                </a>
                <a class="flex mb-4" href="admin-event.php">
                    <div class="w-9 ml-0.5 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Event</h1>
                </a>
                <a class="flex mb-4 sblue font-semibold" href="admin-inquiries.php">
                    <div class="w-9 ml-0.5 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Inquiries</h1>
                </a>
                <a class="flex mb-4" href="admin-visitors.php">
                    <div class="w-9 ml-0.5 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Visitor</h1>
                </a>
                <?php
                if (isset($_SESSION['adminID']) && isset($_SESSION['role']) && $_SESSION['role'] == 'Admin') {
                    echo '
                    <a class="flex mb-4" href="admin-staff.php">
                        <div class="w-9 ml-0.5 mr-auto my-auto"></div>
                        <h1 class="w-full">Staff</h1>
                    </a>';
                }
                ?>
                <a class="flex mb-4" href="admin-feedback.php">
                    <div class="w-9 ml-0.5 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Feedback</h1>
                </a>
                <a class="flex mb-32" href="admin-summary.php">
                    <div class="w-9 ml-1 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Summary</h1>
                </a>
                <hr class="border-1 border-black my-5">
                <a class="flex mb-3" href="admin-profile.php">
                    <div class="w-9 ml-1 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Profile</h1>
                </a>
                <?php
                if (isset($_SESSION['adminID']) && isset($_SESSION['role']) && $_SESSION['role'] == 'Admin') {
                    echo '
                    <a class="flex mb-3" href="admin-access.php">
                        <div class="w-9 ml-1 mr-auto my-auto">
                        </div>
                        <h1 class="w-full">Configuration</h1>
                    </a>
                    ';
                } else {
                    echo '
                    <a class="flex mb-3" href="troubleshoot.php">
                        <div class="w-9 ml-1 mr-auto my-auto">
                        </div>
                        <h1 class="w-full">Troubleshoot</h1>
                    </a>
                    ';
                }
                ?>
                <a class="flex mb-10" href="logout.php">
                    <div class="w-9 ml-1 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Log Out</h1>
                </a>

            </div>

        </div>
        <div class="w-full h-full">
            <div class="bg-white rounded-2xl h-full">
                <!-- Add 'inline-block' class to the image --> <br>
                <span class="font-semibold text-2xl inline-block ml-4 align-middle mb-2">Inquiries Details</span><br>
                <!-- Add 'inline-block' class to the span -->
                <hr class="border-gray-300 mb-6">
                <div class=" p-5 ">
                    <table class="w-full mt-5 border-collapse">
                        <thead>
                            <tr class="bg-gray-200">
                                <th class="p-2 text-s">No</th>
                                <th class="p-2 text-s">Name</th>
                                <th class="p-2 text-s">Email</th>
                                <th class="p-2 text-s">Date</th>
                                <th class="p-2 text-s">Inquiry</th>
                                <th class="p-2 text-s">Status</th>
                                <th class="p-2 text-s">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- PHP -->
                            <?php
                            $sql = "SELECT * FROM inquiry I JOIN visitor V ON I.visitorID = V.visitorID";
                            $result = mysqli_query($conn, $sql);

                            $count = 1;
                            if ($result && mysqli_num_rows($result) > 0) {
                                while ($row = mysqli_fetch_assoc($result)) {

                                    // Format the date to d/m/y
                                    $date = DateTime::createFromFormat('Y-m-d', $row['date'])->format('d/m/y');

                                    // Apply status color classes
                                    $status_class = '';
                                    $status_text = $row['status'];

                                    if ($status_text == 'Pending') {
                                        $status_class = 'text-orange-500'; // Orange for Pending
                                    } elseif ($status_text == 'Completed') {
                                        $status_class = 'text-green-500'; // Green for Completed
                                    } elseif ($status_text == 'No Respond') {
                                        $status_class = 'text-red-500'; // Red for No Respond
                                    }

                                    echo '
                                    <tr class="bg-white">
                                        <td class="p-2 border text-s text-center">' . $count . '</td>
                                        <td class="p-2 border text-s text-center">' . $row['name'] . '</td>
                                        <td class="p-2 border text-s text-center">' . $row['email'] . '</td>
                                        <td class="p-2 border text-s text-center">' . $date . '</td>
                                        <td class="p-2 border text-s text-center">' . $row['inquiryDetails'] . '</td>
                                        <td class="p-2 border text-s font-bold text-center ' . $status_class . '">' . $status_text . '</td>
                                        <td class="p-2 border text-s text-center">
                                            <button onclick="openPopup(' . $row['inquiryID'] . ', \'' . $row['status'] . '\')">
                                                <img style="height: 30px; width: 30px; object-fit: cover; display: block; margin: auto;"  class="rounded-t-xl" src="assets/pen.png" alt="">
                                            </button>
                                        </td>
                                    </tr>';
                                    $count++;
                                }
                            } else {
                                echo '<tr><td colspan="7">No records found.</td></tr>';
                            }

                            ?>
                        </tbody>
                    </table>
                </div>
                <!-- Popup Modal -->
                <div id="editPopup" class="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center hidden">
                    <div class="bg-white p-5 rounded-xl w-1/3">
                        <h2 class="text-xl font-bold mb-4">Update Status</h2>
                        <form action="admin-update-status.php" method="POST">
                            <input type="hidden" id="inquiryID" name="inquiryID">
                            <label for="status" class="block mb-2">Status</label>
                            <select id="status" name="status" class="block w-full p-2 border rounded mb-4">
                                <option value="Completed" id="completed">Completed</option>
                                <option value="No Respond" id="noRespond">No Respond</option>
                                <option value="Pending" id="pending">Pending</option>
                            </select>
                            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Update</button>
                            <button type="button" onclick="closePopup()" class="bg-gray-500 text-white px-4 py-2 rounded mt-2">Cancel</button>
                        </form>
                    </div>
                </div>



                <!-- JavaScript for Handling Popup -->
                <script>
                    function openPopup(inquiryID, status) {
                        document.getElementById('editPopup').classList.remove('hidden');
                        document.getElementById('inquiryID').value = inquiryID; // Set the inquiry ID to hidden input

                        // Set the current status as the selected option
                        document.getElementById('status').value = status;
                    }

                    function closePopup() {
                        document.getElementById('editPopup').classList.add('hidden');
                    }
                </script>

            </div>

        </div>

    </section>

</body>

</html>