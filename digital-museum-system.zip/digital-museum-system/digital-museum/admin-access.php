<?php
include "config.php";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="icon" type="image/png" href="assets/logo.svg" />
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <title>SadaqahTrack</title>
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
        }

        .bground-blue {
            background-color: #0097B2;
        }

        .sblue {
            color: #0097B2;
        }

        /* Style the progress bar fill */
        progress::-webkit-progress-value {
            background-color: #0097B2;
            /* Change the fill color to green */
        }
    </style>
</head>

<body class="bg-slate-200">

    <!-- Navigation Bar -->
    <section class="relative">
        <nav class="bg-white flex flex-row gap-x-5 shadow-xl py-3 px-10">
            <div class="flex gap-x-4  ml-5">
                <img style="height: 80px;" src="assets/logo-museum.png" alt="">
                <h1 class="sblue font-bold text-2xl my-auto">National Art Museum</h1>
            </div>
        </nav>
    </section>

    <section class="flex p-10 gap-x-5 h-full">
        <div class="w-[250px]">
            <div class="flex flex-col bg-white p-5 rounded-2xl">
                <svg class="w-20 mx-auto" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                    <path
                        d="M399 384.2C376.9 345.8 335.4 320 288 320H224c-47.4 0-88.9 25.8-111 64.2c35.2 39.2 86.2 63.8 143 63.8s107.8-24.7 143-63.8zM0 256a256 256 0 1 1 512 0A256 256 0 1 1 0 256zm256 16a72 72 0 1 0 0-144 72 72 0 1 0 0 144z" />
                </svg>
                <h1 class="text-lg  text-center mt-5">
                    <?php echo $_SESSION['role']; ?>
                </h1>
                <h1 class="text-sm  text-center">
                    <?php echo $_SESSION['name']; ?>
                </h1>

                <hr class="border-1 border-black my-5">
                <a class="flex mb-4" href="admin-exhibits.php">
                    <div class="w-10 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Exhibit</h1>
                </a>
                <a class="flex mb-4" href="admin-event.php">
                    <div class="w-9 ml-0.5 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Event</h1>
                </a>
                <a class="flex mb-4" href="admin-inquiries.php">
                    <div class="w-9 ml-0.5 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Inquiries</h1>
                </a>
                <a class="flex mb-4" href="admin-visitors.php">
                    <div class="w-9 ml-0.5 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Visitor</h1>
                </a>
                <?php
                if (isset($_SESSION['adminID']) && isset($_SESSION['role']) && $_SESSION['role'] == 'Admin') {
                    echo '
                    <a class="flex mb-4" href="admin-staff.php">
                        <div class="w-9 ml-0.5 mr-auto my-auto"></div>
                        <h1 class="w-full">Staff</h1>
                    </a>';
                }
                ?>
                <a class="flex mb-4" href="admin-feedback.php">
                    <div class="w-9 ml-0.5 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Feedback</h1>
                </a>
                <a class="flex mb-32" href="admin-summary.php">
                    <div class="w-9 ml-1 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Summary</h1>
                </a>
                <hr class="border-1 border-black my-5">
                <a class="flex mb-3" href="admin-profile.php">
                    <div class="w-9 ml-1 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Profile</h1>
                </a>
                <?php
                if (isset($_SESSION['adminID']) && isset($_SESSION['role']) && $_SESSION['role'] == 'Admin') {
                    echo '
                    <a class="flex mb-3  sblue font-semibold" href="admin-access.php">
                        <div class="w-9 ml-1 mr-auto my-auto">
                        </div>
                        <h1 class="w-full">Configuration</h1>
                    </a>';
                }
                ?>
                <a class="flex mb-10" href="logout.php">
                    <div class="w-9 ml-1 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Log Out</h1>
                </a>

            </div>

        </div>
        <div class="bg-white rounded-2xl p-10 shadow-xl w-11/12">
            <h1 class="text-4xl font-bold text-gray-800 mb-8 text-center">System Configuration</h1>
            <hr class="border-gray-300 mb-8">

            <div class="grid grid-cols-1 md:grid-cols-3 gap-10 mt-[100px]">
                <!-- Make Announcement -->
                <div class="bg-blue-500 text-white p-10 rounded-2xl shadow-lg text-center hover:bg-blue-600 transition cursor-pointer transform hover:scale-110"
                    onclick="window.location.href='admin-configure-announcement.php'">
                    <h1 class="text-2xl font-semibold">📢 Make Announcement</h1>
                    <p class="text-lg opacity-80 mt-4">Create and publish important updates.</p>
                </div>

                <!-- Troubleshooting Inquiries -->
                <div class="bg-red-500 text-white p-10 rounded-2xl shadow-lg text-center hover:bg-red-600 transition cursor-pointer transform hover:scale-110"
                    onclick="window.location.href='admin-configure-troubleshoot.php'">
                    <h1 class="text-2xl font-semibold">🛠️ Troubleshooting Inquiries</h1>
                    <p class="text-lg opacity-80 mt-4">Manage and resolve staff inquiries.</p>
                </div>

                <!-- Create User Account -->
                <div class="bg-green-500 text-white p-10 rounded-2xl shadow-lg text-center hover:bg-green-600 transition cursor-pointer transform hover:scale-110"
                    onclick="openModal()">
                    <h1 class="text-2xl font-semibold">👤 Create User Account</h1>
                    <p class="text-lg opacity-80 mt-4">Register new users for system access.</p>
                </div>
            </div>
        </div>
        <!-- Modal Popup -->
        <div id="userModal" class="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center hidden">
            <div class="bg-white p-8 rounded-lg shadow-lg w-[600px]">
                <h2 class="text-2xl font-bold text-gray-800 mb-4 text-center">Register User</h2>
                <form action="create-account.php" method="POST">

                    <label class="block text-gray-700 font-semibold">Role</label>
                    <select name="role" required class="w-full p-2 border rounded-md mb-4">
                        <option value="Visitor">Visitor</option>
                        <option value="Staff">Staff</option>
                    </select>

                    <label class="block text-gray-700 font-semibold">Full Name</label>
                    <input type="text" name="name" required class="w-full p-2 border rounded-md mb-3">

                    <label class="block text-gray-700 font-semibold">Username</label>
                    <input type="text" name="username" required class="w-full p-2 border rounded-md mb-3">

                    <label class="block text-gray-700 font-semibold">Email</label>
                    <input type="email" name="email" required class="w-full p-2 border rounded-md mb-3">

                    <label class="block text-gray-700 font-semibold">Password</label>
                    <input type="password" name="password" required class="w-full p-2 border rounded-md mb-3">

                    <div class="flex justify-between mt-10">
                        <button type="button" class="bg-gray-500 text-white px-4 py-2 rounded-md" onclick="closeModal()">Cancel</button>
                        <button type="submit" class="bg-green-500 text-white px-4 py-2 rounded-md">Register</button>
                    </div>
                </form>
            </div>
        </div>

        <script>
            function openModal() {
                document.getElementById('userModal').classList.remove('hidden');
            }

            function closeModal() {
                document.getElementById('userModal').classList.add('hidden');
            }
        </script>


    </section>

</body>

</html>