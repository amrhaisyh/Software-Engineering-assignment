<?php
include 'config.php';

$visitorID = $_SESSION['visitorID'];

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exhibit | National Art Museum</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background: #f5f0e1;
        }

        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 20px;
            background-color: #f4f4f4;
            border-bottom: 1px solid #ccc;
        }

        header img {
            height: 60px;
        }

        nav {
            display: flex;
            gap: 15px;
        }

        nav a {
            text-decoration: none;
            color: #333;
            padding: 8px 15px;
            border: 1px solid transparent;
            border-radius: 5px;
        }

        nav a:hover {
            background-color: #ddd;
            border-color: #ccc;
        }

        .search-bar {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .search-bar input {
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        /* Style for the active link */
        nav a.active {
            color: brown;
            font-weight: normal;
        }

        footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            padding: 10px;
            background-color: #f4f4f4;
        }

        .exhibits-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: flex-start;
            gap: 20px;
            padding: 40px;
            margin-left: 30px;
        }

        .exhibit {
            width: calc(33.33% - 20px);
            max-width: 500px;
            margin: 10px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 20px;
            background-color: white;
            text-align: left;
            box-sizing: border-box;
        }

        .exhibit img {
            width: 100%;
            height: 450px;
            border-radius: 5px;
        }

        .exhibit h3 {
            font-size: 1.2rem;
            color: #333;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .exhibit p {
            font-size: 1rem;
            color: #666;
            text-align: left;
        }

        .rating {
            margin-top: 10px;
            font-weight: bold;
            color: #f39c12;
        }

        /* Favorite (Heart) Button */
        .favorite-btn {
            background: none;
            border: none;
            font-size: 2.5rem;
            cursor: pointer;
            color: #999;
            /* Default empty heart color */
        }

        .favorite-btn.active {
            color: red;
            /* Filled heart when active */
        }

        .feedback-form {
            padding: 30px;
            border-radius: 50px;
            border: 1px solid #ccc;
            background: #f4f4f4;
            width: 500px;
            margin: 50px 0 50px 60px;
            /* Added margin for spacing */
        }

        .feedback-form select,
        .feedback-form textarea {
            width: 100%;
            padding: 8px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .title-group {
            margin-left: 60px;
            font-size: 30px;
        }
    </style>
</head>

<body>
    <header>
        <img src="logo.jpg" alt="National Art Museum Logo">
        <nav>
            <a href="home.php">Home</a>
            <a href="exhibit.php" class="active">Exhibit</a>
            <a href="event.php">Event</a>
            <a href="favourite.php">Favourite</a>
            <a href="feedback.php">Feedback</a>
            <a href="inquiry.php">Contact Us</a>
            <a href="profile.php">Profile</a>
        </nav>
        <form method="get" action="search.php">
            <input type="text" name="query" placeholder="Search..." value="">
            <!-- Hidden field to capture the current page -->
            <input type="hidden" name="current_page" value="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])); ?>">
            <button type="submit" style="margin-top:10px;">
                <img src="search.jpg" alt="Search" style="width: 18px; height: 17px; cursor: pointer;">
            </button>
        </form>
    </header>
    <div class="feedback-form">
        <h2>Search by Category</h2>
        <form id="search-form" method="GET">
            <div style="display: flex; align-items: center;">
                <select id="search" name="search" style="width: 350px; margin-right: 5px;">
                    <option value="" disabled selected>Select a category...</option>
                    <option value="Art">Art</option>
                    <option value="Science">Science</option>
                    <option value="Historical">Historical</option>
                </select> <button type="submit" name="submit">
                    <img src="search.jpg" alt="Search" style="width: 30px; height: 30px; cursor: pointer;">
                </button>
            </div>
        </form>
    </div>

    <div class="exhibits-container">
        <?php
        // Check if a search term is provided
        $searchQuery = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

        // Construct the SQL query
        if (!empty($searchQuery)) {
            $query = "SELECT * FROM exhibit WHERE category LIKE '%$searchQuery%'";
        } else {
            $query = "SELECT * FROM exhibit";
        }

        // Execute the query
        $result = mysqli_query($conn, $query);

        // Check if any results were returned
        if (mysqli_num_rows($result) > 0) {

            // Loop through all the exhibits and display them
            while ($exhibit = mysqli_fetch_assoc($result)) {
                // Check if the image path exists in the database and append a default image if not
                $imagePath = !empty($exhibit['image']) ? $exhibit['image'] : 'images/default.jpg';

                $exhibitID = $exhibit['exhibitID'];
                $favQuery = "SELECT * FROM favourite WHERE visitorID = $visitorID AND exhibitID = $exhibitID";
                $favResult = mysqli_query($conn, $favQuery);
                $isFavorite = mysqli_num_rows($favResult) > 0;

                echo "<div class='exhibit'>";
                echo "<img src='/digital-museum-system/digital-museum/" . $imagePath . "' alt='Exhibit Image'>";

                echo "<h3>" . $exhibit['title'];
                echo " <button class='favorite-btn " . ($isFavorite ? "active" : "") . "' 
                         onclick='toggleFavorite(this, $exhibitID)'>&#" . ($isFavorite ? "10084;" : "9825;") . "</button>"; // Filled or empty heart
                echo "</h3>";

                echo "<p><strong>Category:</strong> " . $exhibit['category'] . "</p>";
                echo "<p><strong>Description:</strong> " . $exhibit['description'] . "</p>";
                echo "<p class='rating'><strong>Rating:</strong> " . $exhibit['rating'] . "/10</p>";
                echo "</div>";
            }
        } else {
            // Display a message if no results are found
            echo "<p>No exhibits found for the category: <strong>" . htmlspecialchars($searchQuery) . "</strong>.</p>";
        }
        ?>
    </div>


    <footer>
        &copy; 2025 National Art Museum. All rights reserved.
    </footer>

    <script>
        // function toggleFavorite(button) {
        //     if (button.classList.contains("active")) {
        //         button.classList.remove("active");
        //         button.innerHTML = "&#9825;"; // Empty heart (♡)
        //     } else {
        //         button.classList.add("active");
        //         button.innerHTML = "&#10084;"; // Filled heart (❤️)
        //     }
        // }

        function toggleFavorite(button, exhibitID) {
            let isActive = button.classList.contains("active");

            // AJAX request to add or remove from favorites
            let xhr = new XMLHttpRequest();
            xhr.open("POST", "update-favourites.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onload = function() {
                if (xhr.status === 200) {
                    if (isActive) {
                        button.classList.remove("active");
                        button.innerHTML = "&#9825;"; // Empty heart (♡)
                    } else {
                        button.classList.add("active");
                        button.innerHTML = "&#10084;"; // Filled heart (❤️)
                    }
                } else {
                    alert("Failed to update favorites.");
                }
            };

            xhr.send("exhibitID=" + exhibitID + "&action=" + (isActive ? "remove" : "add"));
        }
    </script>
</body>

</html>

<?php
// Close the database connection
mysqli_close($conn);
?>