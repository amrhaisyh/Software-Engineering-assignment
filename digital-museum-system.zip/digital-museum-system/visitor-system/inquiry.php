<?php
include 'config.php';

// Process the form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    // Fetch visitorID from the visitor table using the name and email
    $query = "SELECT visitorID FROM visitor WHERE name = '$name' AND email = '$email'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        // Fetch visitorID
        $user = mysqli_fetch_assoc($result);
        $visitorID = $user['visitorID'];

        // Store the inquiry details into the inquiry table (corrected table name)
        $inquiryQuery = "INSERT INTO inquiry (visitorID, inquiryDetails) VALUES ('$visitorID', '$message')";
        if (mysqli_query($conn, $inquiryQuery)) {
            $successMessage = "Your inquiry has been submitted successfully.";
        } else {
            $errorMessage = "Error: " . mysqli_error($conn);
        }
    } else {
        $errorMessage = "No matching visitor found with the provided name and email.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us | National Art Museum</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background-color: #f5f0e1;
        }

        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 20px;
            background-color: #f4f4f4;
            border-bottom: 1px solid #ccc;
        }

        header img {
            height: 60px;
        }

        nav {
            display: flex;
            gap: 15px;
        }

        nav a {
            text-decoration: none;
            color: #333;
            padding: 8px 15px;
            border: 1px solid transparent;
            border-radius: 5px;
        }

        nav a:hover {
            background-color: #ddd;
            border-color: #ccc;
        }

        .search-bar {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .search-bar input {
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        /* Style for the active link */
        nav a.active {
            color: brown;
            font-weight: normal;
        }

        .contact-container {
            max-width: 500px;
            margin: 40px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #f9f9f9;
            text-align: center;
        }

        .contact-container h2 {
            margin-bottom: 20px;
        }

        .contact-container input,
        .contact-container textarea {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .contact-container button {
            padding: 10px 20px;
            background-color: brown;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .contact-container button:hover {
            background-color: darkred;
        }

        footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            padding: 10px;
            background-color: #f4f4f4;
        }
    </style>
</head>

<body>
    <header>
        <img src="logo.jpg" alt="National Art Museum Logo">
        <nav>
            <a href="home.php">Home</a>
            <a href="exhibit.php">Exhibit</a>
            <a href="event.php">Event</a>
            <a href="favourite.php">Favourite</a>
            <a href="feedback.php">Feedback</a>
            <a href="inquiry.php" class="active">Contact Us</a>
            <a href="profile.php">Profile</a>
        </nav>
        <form method="get" action="search.php">
            <input type="text" name="query" placeholder="Search..." value="">
            <!-- Hidden field to capture the current page -->
            <input type="hidden" name="current_page" value="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])); ?>">
            <button type="submit" style="margin-top:10px;">
                <img src="search.jpg" alt="Search" style="width: 18px; height: 17px; cursor: pointer;">
            </button>
        </form>
    </header>

    <div class="contact-container">
        <h2>How Can We Help You?</h2>

        <?php if (isset($successMessage)) { ?>
            <div style="color: green;"><?php echo $successMessage; ?></div>
        <?php } elseif (isset($errorMessage)) { ?>
            <div style="color: red;"><?php echo $errorMessage; ?></div>
        <?php } ?>

        <form method="POST" action="inquiry.php">
            <input type="text" name="name" placeholder="Name" style="width: 480px;" required>
            <input type="email" name="email" placeholder="Email" style="width: 480px;" required>
            <textarea name="message" rows="5" placeholder="Message" style="width: 480px;" required></textarea>
            <button type="submit">Submit</button>
        </form>
    </div>

    <footer>
        &copy; 2025 National Art Museum. All rights reserved.
    </footer>

    <script>
        // Get all the navigation links
        const navLinks = document.querySelectorAll("nav a");

        // Add a click event listener to each link
        navLinks.forEach(link => {
            link.addEventListener("click", function() {
                // Remove the 'active' class from all links
                navLinks.forEach(nav => nav.classList.remove("active"));
                // Add the 'active' class to the clicked link
                this.classList.add("active");
            });
        });
    </script>
</body>

</html>