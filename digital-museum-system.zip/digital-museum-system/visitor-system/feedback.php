<?php
include 'config.php';

$visitorID = $_SESSION['visitorID'];

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exhibit | National Art Museum</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background: #f5f0e1;
        }

        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 20px;
            background-color: #f4f4f4;
            border-bottom: 1px solid #ccc;
        }

        header img {
            height: 60px;
        }

        nav {
            display: flex;
            gap: 15px;
        }

        nav a {
            text-decoration: none;
            color: #333;
            padding: 8px 15px;
            border: 1px solid transparent;
            border-radius: 5px;
        }

        nav a:hover {
            background-color: #ddd;
            border-color: #ccc;
        }

        .search-bar {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .search-bar input {
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        /* Style for the active link */
        nav a.active {
            color: brown;
            font-weight: normal;
        }

        footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            padding: 10px;
            background-color: #f4f4f4;
        }

        .exhibits-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: flex-start;
            gap: 20px;
            padding: 40px;
            margin-left: 30px;
            margin-bottom: 30px;
        }

        .exhibit {
            width: calc(33.33% - 20px);
            max-width: 500px;
            margin: 10px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 20px;
            background-color: white;
            text-align: left;
            box-sizing: border-box;
        }

        .exhibit img {
            width: 100%;
            height: 450px;
            border-radius: 5px;
        }

        .exhibit h3 {
            font-size: 1.2rem;
            color: #333;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .exhibit p {
            font-size: 1rem;
            color: #666;
            text-align: left;
        }

        .rating {
            margin-top: 10px;
            font-weight: bold;
            color: #f39c12;
        }

        /* Favorite (Heart) Button */
        .favorite-btn {
            background: none;
            border: none;
            font-size: 2.5rem;
            cursor: pointer;
            color: #999;
            /* Default empty heart color */
        }

        .favorite-btn.active {
            color: red;
            /* Filled heart when active */
        }

        .feedback-form {
            padding: 60px;
            border-radius: 50px;
            border: 1px solid #ccc;
            background: #f4f4f4;
            width: 500px;
            margin: 50px;
            /* Added margin for spacing */
        }

        .feedback-form input,
        .feedback-form textarea {
            width: 100%;
            padding: 8px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .popup-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
        }

        .popup-content {
            background: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            width: 450px;
            height: 400px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            position: relative;
        }

        .close-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
        }

        .popup-image {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 10px;
        }

        .rating-section {
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 10px 0;
        }

        .rating-label {
            font-weight: bold;
            margin-right: 10px;
        }

        .stars span {
            font-size: 24px;
            cursor: pointer;
            color: gray;
            /* Default star color */
        }

        .stars span.filled {
            color: gold;
            /* Filled star color */
        }

        .hidden {
            display: none;
        }

        .popup-textarea {
            width: 400px;
            height: 80px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin: 10px 0;
        }

        .popup-buttons {
            display: flex;
            justify-content: space-evenly;
        }

        .cancel-btn,
        .submit-btn {
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }

        .cancel-btn {
            background: #ccc;
            color: black;
        }

        .submit-btn {
            background: #28a745;
            color: white;
        }

        .cancel-btn:hover {
            background: #bbb;
        }

        .submit-btn:hover {
            background: #218838;
        }
    </style>
</head>

<body>
    <header>
        <img src="logo.jpg" alt="National Art Museum Logo">
        <nav>
            <a href="home.php">Home</a>
            <a href="exhibit.php">Exhibit</a>
            <a href="event.php">Event</a>
            <a href="favourite.php">Favourite</a>
            <a href="feedback.php" class="active">Feedback</a>
            <a href="inquiry.php">Contact Us</a>
            <a href="profile.php">Profile</a>
        </nav>
        <div class="search-bar">
            <form method="get" action="search.php">
                <input type="text" name="query" placeholder="Search..." value="">
                <!-- Hidden field to capture the current page -->
                <input type="hidden" name="current_page" value="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])); ?>">
                <button type="submit" style="margin-top:10px;">
                    <img src="search.jpg" alt="Search" style="width: 18px; height: 17px; cursor: pointer;">
                </button>
            </form>
        </div>
    </header>
    <div class="feedback-form">
        <h2>Share Your Thoughts About Our Exhibits!</h2>
        <form id="search-form" method="GET">
            <div style="display: flex; align-items: center;">
                <input type="text" id="search" name="search" placeholder="Search exhibit.." style="width: 350px; margin-right: 5px;">
                <button type="submit" name="submit">
                    <img src="search.jpg" alt="Search" style="width: 30px; height: 30px; cursor: pointer;" onclick="searchExhibit()">
                </button>
            </div>
        </form>
    </div>
    <div id="exhibits-container" class='exhibits-container'>
        <?php
        if (isset($_GET['search'])) {
            if (trim($_GET['search']) === "") {
                echo "<script>alert('The search field cannot be empty!'); window.history.back();</script>";
                exit(); // Stop execution after showing the alert
            }

            $searchQuery = mysqli_real_escape_string($conn, $_GET['search']);
            $query = "SELECT * FROM exhibit WHERE title LIKE '%$searchQuery%' OR category LIKE '%$searchQuery%'";
            $result = mysqli_query($conn, $query);

            if (mysqli_num_rows($result) > 0) {
                while ($exhibit = mysqli_fetch_assoc($result)) {
                    $imagePath = !empty($exhibit['image']) ? $exhibit['image'] : 'images/default.jpg';
                    $exhibitID = $exhibit['exhibitID'];

                    echo "<div class='exhibit'>";
                    echo "<img src='/digital-museum-system/digital-museum/" . $imagePath . "' alt='Exhibit Image'>";
                    echo "<h3>" . $exhibit['title'] . "</h3>";
                    echo "<p><strong>Category:</strong> " . $exhibit['category'] . "</p>";
                    echo "<p><strong>Description:</strong> " . $exhibit['description'] . "</p>";
                    echo "<p class='rating'><strong>Rating:</strong> " . $exhibit['rating'] . "/10</p>";
                    echo "<button class='give-rating' onclick=\"openFeedbackForm('" . addslashes($exhibit['title']) . "', '" . addslashes($exhibitID) . "','" . addslashes($imagePath) . "')\">Give Rating</button>";
                    echo "</div>";
                }
            } else {
                echo "<script>alert('No results found.');</script>";
            }
        }
        ?>

    </div>
    <div id="feedback-form" class="hidden popup-container">
        <div class="popup-content">
            <button class="close-btn" onclick="closeFeedbackForm()">&times;</button>
            <img id="exhibit-image" src="placeholder.jpg" alt="Exhibit Image" class="popup-image">
            <h2 id="form-title">Exhibit Title Here</h2>
            <form action="manage-feedback.php" method="POST">
                <div class="rating-section">
                    <label class="rating-label">Rate Me</label>
                    <div class="stars">
                        <span onclick="setRating(1)">☆</span>
                        <span onclick="setRating(2)">☆</span>
                        <span onclick="setRating(3)">☆</span>
                        <span onclick="setRating(4)">☆</span>
                        <span onclick="setRating(5)">☆</span>
                    </div>
                </div>
                <input type="hidden" name="numericRating" id="numericRating" value="">
                <input type="hidden" name="imageInput" id="image-input" value="">
                <input type="hidden" name="exhibitID" id="exhibit-Id" value="">
                <textarea name="comments" placeholder="Leave your comments here..." class="popup-textarea"></textarea>
                <input type="hidden" name="exhibitTitle" id="exhibitTitle" value="">
                <div class="popup-buttons">
                    <button type="button" class="cancel-btn" onclick="closeFeedbackForm()">Cancel</button>
                    <button type="submit" class="submit-btn">Submit</button>
                </div>
            </form>
        </div>
    </div>
    <footer>
        &copy; 2025 National Art Museum. All rights reserved.
    </footer>

    <script>
        function openFeedbackForm(title, exhibitID, image) {
            document.getElementById('form-title').textContent = title;
            document.getElementById('exhibitTitle').value = title;
            document.getElementById('exhibit-image').src = "/digital-museum-system/digital-museum/" + image;
            document.getElementById('feedback-form').classList.remove('hidden');
            document.getElementById('image-input').value = image;
            document.getElementById('exhibit-Id').value = exhibitID;

        }

        function closeFeedbackForm() {
            document.getElementById('feedback-form').classList.add('hidden');
        }

        function setRating(stars) {
            let numericValue = stars * 2; // Convert stars to numeric rating
            document.getElementById('numericRating').value = numericValue;

            let starsElements = document.querySelectorAll('.stars span');
            starsElements.forEach((star, index) => {
                star.classList.toggle('filled', index < stars);
            });
        }
    </script>
</body>

</html>

<?php
// Close the database connection
mysqli_close($conn);
?>