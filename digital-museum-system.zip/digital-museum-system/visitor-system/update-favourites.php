<?php
include 'config.php';


if (!isset($_SESSION['visitorID'])) {
    echo "User not logged in";
    exit;
}

$visitorID = $_SESSION['visitorID'];
$exhibitID = $_POST['exhibitID'];
$action = $_POST['action'];

if ($action === "add") {
    // Insert into favourites table
    $query = "INSERT INTO favourite (visitorID, exhibitID) VALUES (?, ?)";
} elseif ($action === "remove") {
    // Remove from favourites table
    $query = "DELETE FROM favourite WHERE visitorID = ? AND exhibitID = ?";
}

$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "ii", $visitorID, $exhibitID);
mysqli_stmt_execute($stmt);
mysqli_stmt_close($stmt);

echo "Success";

?>