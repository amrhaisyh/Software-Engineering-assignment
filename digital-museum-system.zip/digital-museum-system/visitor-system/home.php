<?php
include 'config.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home | National Art Museum</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 20px;
            background-color: #f4f4f4;
            border-bottom: 1px solid #ccc;
        }

        header img {
            height: 60px;
        }

        nav {
            display: flex;
            gap: 15px;
        }

        nav a {
            text-decoration: none;
            color: #333;
            padding: 8px 15px;
            border: 1px solid transparent;
            border-radius: 5px;
        }

        nav a:hover {
            background-color: #ddd;
            border-color: #ccc;
        }

        .search-bar {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .search-bar input {
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .section {
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            margin: 0;
            padding: 20px;
            border: none;
        }

        .section h2 {
            font-size: 1.5rem;
            text-align: center;
            margin-bottom: 20px;
            margin-top: -30px;
            /* Adjusted to move the title higher */
        }

        .welcome-section {
            background-image: url('museum background.jpg');
            background-size: cover;
            background-position: center;
            color: white;
            text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.7);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: flex-end;
            padding: 20px;
        }

        .welcome-section h1 {
            font-size: 2.6rem;
            font-weight: 800;
            text-align: left;
            line-height: 1.5;
            margin: 0;
            padding-right: 200px;
            padding-bottom: 200px;
        }

        .about-section {
            background-color: #f9f9f9;
            display: flex;
            align-items: center;
            padding: 50px;
            text-align: left;
        }

        .about-section h2 {
            font-size: 1.8rem;
            text-align: center;
            margin-top: -100px;
            /* Adjust this value to move the title down or up */
            margin-bottom: 100px;
            /* Adjust this value to control the space below the title */
        }

        .about-content {
            display: flex;
            align-items: center;
            max-width: 80%;
            justify-content: flex-start;
        }

        .about-content img {
            width: 600px;
            border-radius: 5px;
            margin-right: 20px;
            margin-left: -100px;
        }

        .about-content p {
            flex: 1;
            font-size: 1rem;
            margin-left: 100px;
            width: 500px;
        }

        .feedback-section {
            background-color: #e6ffe6;
        }

        nav a.active {
            color: brown;
            font-weight: normal;
        }

        footer {
            margin-top: 20px;
            text-align: center;
            padding: 10px;
            background-color: #f4f4f4;
        }

        .main-content img {
            max-width: 100%;
            height: auto;
        }
    </style>
</head>

<body>
    <header>
        <img src="logo.jpg" alt="National Art Museum Logo">
        <nav>
            <a href="home.php" class="active">Home</a>
            <a href="exhibit.php">Exhibit</a>
            <a href="event.php">Event</a>
            <a href="favourite.php">Favourite</a>
            <a href="feedback.php">Feedback</a>
            <a href="inquiry.php">Contact Us</a>
            <a href="profile.php">Profile</a>
        </nav>
        <form method="get" action="search.php">
            <input type="text" name="query" placeholder="Search..." value="">
            <!-- Hidden field to capture the current page -->
            <input type="hidden" name="current_page" value="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])); ?>">
            <button type="submit" style="margin-top:10px;">
                <img src="search.jpg" alt="Search" style="width: 18px; height: 17px; cursor: pointer;">
            </button>
        </form>
    </header>

    <div class="section welcome-section">
        <h1>WELCOME TO<br>NATIONAL ART MUSEUM</h1>
    </div>

    <div class="section about-section">
        <h2>About Us</h2>
        <div class="about-content">
            <img src="about_us.jpg" alt="About Us Image">
            <p>The National Art Museum is a renowned institution dedicated to preserving and showcasing art from diverse cultures and time periods. It houses an extensive collection of paintings, sculptures, and artifacts that highlight the evolution of human creativity. Visitors can explore works from classical to contemporary artists, including both well-known masterpieces and hidden gems. The museum’s mission is to educate, inspire, and engage the public through immersive exhibitions and interactive programs. With its stunning architecture and serene atmosphere, it offers a perfect environment for reflection and discovery. Regular workshops, lectures, and guided tours make it a vibrant space for learning. Whether you are an art enthusiast or a casual visitor, the museum provides something for everyone. It is not just a place for art lovers but a cultural hub for the entire community. Come and experience the timeless beauty of art that connects us all.</p>
        </div>
    </div>

    <footer>
        &copy; 2025 National Art Museum. All rights reserved.
    </footer>

    <script>
        const navLinks = document.querySelectorAll("nav a");
        navLinks.forEach(link => {
            link.addEventListener("click", function() {
                navLinks.forEach(nav => nav.classList.remove("active"));
                this.classList.add("active");
            });
        });
    </script>
</body>

</html>