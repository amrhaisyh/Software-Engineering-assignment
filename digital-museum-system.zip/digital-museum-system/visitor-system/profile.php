<?php
include 'config.php';

// Check if user is logged in (based on session)
if (!isset($_SESSION['username'])) {
    header('Location: login.php'); // Redirect to login page if not logged in
    exit();
}

// Fetch visitor details from the database based on session username
$username = $_SESSION['username'];

// Ensure the table name is 'visitor' and the fields are correct in your query
$query = "SELECT name, email FROM visitor WHERE username = '$username'";  // Query updated to use 'visitor' table

$result = mysqli_query($conn, $query);

if ($result) {
    $user = mysqli_fetch_assoc($result);
    $fullName = $user['name'];
    $email = $user['email'];
} else {
    die("Error fetching user data: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile | National Art Museum</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background-color: #f5f0e1;
        }

        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 20px;
            background-color: #f4f4f4;
            border-bottom: 1px solid #ccc;
        }

        header img {
            height: 60px;
        }

        nav {
            display: flex;
            gap: 15px;
        }

        nav a {
            text-decoration: none;
            color: #333;
            padding: 8px 15px;
            border: 1px solid transparent;
            border-radius: 5px;
        }

        nav a:hover {
            background-color: #ddd;
            border-color: #ccc;
        }

        nav a.active {
            color: brown;
            font-weight: normal;
        }

        .search-bar {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .search-bar input {
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .profile-container {
            display: flex;
            align-items: flex-start;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
        }

        .profile-info {
            flex: 1;
            text-align: left;
        }

        .profile-info h2 {
            margin-bottom: 20px;
        }

        .profile-icon {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            overflow: hidden;
            /* Ensures the image stays within the circular boundary */
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 10px;
        }

        .profile-icon img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            /* Ensures the image fills the space without distortion */
        }

        .profile-details {
            flex: 2;
        }

        .profile-details label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .profile-details input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: white;
        }

        .logout-button {
            display: block;
            width: 20%;
            padding: 10px;
            background-color: darkred;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
        }

        .logout-button:hover {
            background-color: #555;
        }

        footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            padding: 10px;
            background-color: #f4f4f4;
        }
    </style>
</head>

<body>
    <header>
        <img src="logo.jpg" alt="National Art Museum Logo">
        <nav>
            <a href="home.php">Home</a>
            <a href="exhibit.php">Exhibit</a>
            <a href="event.php">Event</a>
            <a href="favourite.php">Favourite</a>
            <a href="feedback.php">Feedback</a>
            <a href="inquiry.php">Contact Us</a>
            <a href="profile.php" class="active">Profile</a>
        </nav>
        <form method="get" action="search.php">
            <input type="text" name="query" placeholder="Search..." value="">
            <!-- Hidden field to capture the current page -->
            <input type="hidden" name="current_page" value="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])); ?>">
            <button type="submit" style="margin-top:10px;">
                <img src="search.jpg" alt="Search" style="width: 18px; height: 17px; cursor: pointer;">
            </button>
        </form>
    </header>

    <div class="profile-container">
        <div class="profile-info">
            <h2>YOUR PROFILE</h2>
            <div class="profile-icon">
                <img id="profile-pic" src="profile icon.jpg" alt="Profile Picture">
            </div>
        </div>
        <div class="profile-details">
            <label for="full-name">Full Name</label>
            <input type="text" id="full-name" value="<?php echo $fullName; ?>" disabled>

            <label for="username">Username</label>
            <input type="text" id="username" value="<?php echo $username; ?>" disabled>

            <label for="email">Email</label>
            <input type="email" id="email" value="<?php echo $email; ?>" disabled>

            <button class="logout-button" onclick="logout()">Logout</button>
        </div>
    </div>

    <footer>
        &copy; 2025 National Art Museum. All rights reserved.
    </footer>

    <script>
        function logout() {
            localStorage.clear(); // Clears stored data
            window.location.href = "login.php"; // Redirects to login page
        }
    </script>

</body>

</html>