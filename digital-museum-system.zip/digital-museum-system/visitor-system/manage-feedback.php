<?php
include 'config.php';
$visitorID = $_SESSION['visitorID'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $exhibitTitle = mysqli_real_escape_string($conn, $_POST['exhibitTitle']);
    $numericRating = (float)$_POST['numericRating']; // Retrieve numeric rating
    $comments = mysqli_real_escape_string($conn, $_POST['comments']);
    $imageInput = mysqli_real_escape_string($conn, $_POST['imageInput']);
    $exhibitID = mysqli_real_escape_string($conn, $_POST['exhibitID']);

    // Insert new feedback
    $query = "INSERT INTO feedback (visitorID, image, title, rating, comments, date) 
              VALUES ('$visitorID', '$imageInput', '$exhibitTitle', '$numericRating', '$comments', NOW())";

    if (mysqli_query($conn, $query)) {
        
        // Update exhibit rating
        $updateQuery = "UPDATE exhibit 
                        SET rating = (SELECT ROUND(SUM(rating) / COUNT(*), 1) FROM feedback WHERE title = '$exhibitTitle') 
                        WHERE exhibitID = '$exhibitID'";

        if (mysqli_query($conn, $updateQuery)) {
            echo "<script>alert('Thank you for your feedback!');</script>";
            echo "<script>window.location.href = 'feedback.php';</script>";
        } else {
            echo "Error updating exhibit rating: " . mysqli_error($conn);
        }

    } else {
        echo "Error submitting feedback: " . mysqli_error($conn);
    }
}
?>
