<?php
include 'config.php';

$error_message = ""; // Variable to hold the error message

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve form data
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query to check if the user exists in the database
    $sql = "SELECT * FROM visitor WHERE username = '$username' AND password = '$password'";
    $result = mysqli_query($conn, $sql);

    // Check if the query returned results
    if ($result && mysqli_num_rows($result) > 0) {
        // Fetch user data
        $row = mysqli_fetch_assoc($result);

        // Store user details in session
        $_SESSION['username'] = $username;
        $_SESSION['visitorID'] = $row['visitorID'];

        // Redirect to home page
        header("Location: home.php");
        exit;
    } else {
        // Invalid login credentials
        $error_message = "Invalid username or password. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            position: relative;
            overflow: hidden;
        }

        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('museum background.jpg') no-repeat center center fixed;
            background-size: cover;
            opacity: 0.7;
            z-index: -1;
        }

        .container {
            width: 350px;
            height: 340px;
            background: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
            z-index: 1;
        }

        .container img {
            width: 100px;
            height: auto;
            margin-bottom: -10px;
        }

        .container h2 {
            margin-bottom: 20px;
            font-size: 18px;
            color: #333;
        }

        .form-group {
            margin-bottom: 15px;
            text-align: left;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-group input:focus {
            outline: none;
            border-color: #007bff;
        }

        .link {
            font-size: 14px;
            color: #007bff;
            text-decoration: none;
        }

        .link:hover {
            text-decoration: underline;
        }

        .btn {
            width: 100%;
            padding: 10px;
            border: none;
            background-color: #007bff;
            color: white;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .icon {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .icon img {
            width: 20px;
            height: 20px;
        }
    </style>
</head>

<body>

    <!-- Login Form -->
    <div class="container">
        <img src="logo.jpg" alt="Logo">
        <h2>Login to Your Account</h2>
        <form action="login.php" method="POST">
            <div class="form-group">
                <div class="icon">
                    <img src="profile icon.jpg" alt="User Icon">
                    <input type="text" id="username" name="username" placeholder="Username" required>
                </div>
            </div>
            <div class="form-group">
                <div class="icon">
                    <img src="password icon.jpg" alt="Password Icon">
                    <input type="password" id="password" name="password" placeholder="Password" required>
                </div>
            </div>
            <p>Doesn't have an account? <a href="signup.php" class="link">Sign Up Here</a></p>
            <button type="submit" class="btn">Login</button>
        </form>
    </div>

    <!-- JavaScript alert for invalid login credentials -->
    <?php if ($error_message): ?>
        <script type="text/javascript">
            alert("<?php echo $error_message; ?>");
        </script>
    <?php endif; ?>

</body>

</html>