<?php
    include 'config.php';
	
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Handle form submission
        $exhibitTitle = $_POST['exhibitTitle'];
        $rating = $_POST['rating'];
        $comments = $_POST['comments'];

        // Insert feedback into the database
        $query = "INSERT INTO feedback (exhibit_title, rating, comments) VALUES ('$exhibitTitle', '$rating', '$comments')";
        if (mysqli_query($conn, $query)) {
            echo "<script>alert('Feedback submitted successfully!');</script>";
        } else {
            echo "<script>alert('Error submitting feedback.');</script>";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback | National Art Museum</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            background: #f5f0e1;
            overflow-y: auto; /* Allow vertical scrolling for the entire screen */
        }

        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 20px;
            background-color: #f4f4f4;
            border-bottom: 1px solid #ccc;
        }

        header img {
            height: 60px;
        }

        nav {
            display: flex;
            gap: 15px;
        }

        nav a {
            text-decoration: none;
            color: #333;
            padding: 8px 15px;
            border: 1px solid transparent;
            border-radius: 5px;
        }

        nav a:hover {
            background-color: #ddd;
            border-color: #ccc;
        }

        .search-bar {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .search-bar input {
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        nav a.active {
            color: brown;
            font-weight: normal;
        }

        .feedback-form {
            padding: 60px;
            border-radius: 50px;
            border: 1px solid #ccc;
            background: #f4f4f4;
            width: 500px;
            margin: 50px; /* Added margin for spacing */
        }

        .feedback-form input, .feedback-form textarea {
            width: 100%;
            padding: 8px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .feedback-form img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            display: block;
            margin: 10px 0;
        }

        .stars {
            display: flex;
            gap: 5px;
        }

        .stars span {
            cursor: pointer;
            font-size: 20px;
            color: black; /* Default color for stars */
        }

        .filled {
            color: gold; /* Color for filled stars */
        }

        .buttons {
            display: flex;
            justify-content: right;
            padding: 10px 20px;
            background-color: #f4f4f4;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .buttons:hover {
            background-color: #f4f4f4;
        }

        footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            padding: 10px;
            background-color: #f4f4f4;
        }
    </style>
</head>
<body>
    <header>
        <img src="logo.jpg" alt="National Art Museum Logo">
        <nav>
            <a href="home.php">Home</a>
            <a href="exhibit.php">Exhibit</a>
            <a href="event.php">Event</a>
            <a href="favourite.php">Favourite</a>
            <a href="feedback.php" class="active">Feedback</a>
            <a href="inquiry.php">Contact Us</a>
            <a href="profile.php">Profile</a>
        </nav>
        <div class="search-bar">
            <input type="text" placeholder="Search">
        </div>
    </header>

    <div class="feedback-form">
        <h2>Share Your Thoughts About Our Exhibits!</h2>
        <div style="display: flex; align-items: center;">
            <input type="text" id="search" placeholder="Search exhibit/event/category" style="width: 350px; margin-right: 5px;">
            <img src="search.jpg" alt="Search" style="width: 30px; height: 30px; cursor: pointer;" onclick="searchExhibit()">
        </div>

        <div id="feedback-form" style="display:none;">
            <img id="exhibit-image" src="placeholder.jpg" alt="Exhibit Image">
            <label id="title" style="font-weight: bold;">Exhibit Title Here</label>
            <form action="feedback.php" method="POST">
                <div style="display: flex; align-items: center;">
                    <label id="title" style="font-weight: bold; margin-right: 10px;">Rate Me</label>
                    <div class="stars">
                        <span onclick="setRating(1)" name="rating" value="1">☆</span>
                        <span onclick="setRating(2)" name="rating" value="2">☆</span>
                        <span onclick="setRating(3)" name="rating" value="3">☆</span>
                        <span onclick="setRating(4)" name="rating" value="4">☆</span>
                        <span onclick="setRating(5)" name="rating" value="5">☆</span>
                    </div>
                </div>
                <textarea name="comments" placeholder="Comments (optional)"></textarea>
                <input type="hidden" name="exhibitTitle" id="exhibitTitle" value="Exhibit Title Here">
                <div class="buttons">
                    <button type="button" onclick="cancelFeedback()">Cancel</button>
                    <button type="submit">Submit</button>
                </div>
            </form>
        </div>
    </div>

    <footer>
        &copy; 2025 National Art Museum. All rights reserved.
    </footer>

    <script>
        function searchExhibit() {
            document.getElementById('feedback-form').style.display = 'block';
        }

        let currentRating = 0; // Variable to track the current rating

        function setRating(rating) {
            let stars = document.querySelectorAll('.stars span');

            // If the clicked star is already filled, decrease the rating by 1
            if (currentRating === rating) {
                currentRating -= 1; // Decrease the rating
            } else {
                currentRating = rating; // Update to the new rating
            }

            // Update the stars based on the current rating
            stars.forEach((star, index) => {
                star.textContent = index < currentRating ? '⭐' : '☆'; // Use '⭐' for filled stars and '☆' for unfilled stars
            });
        }

        function cancelFeedback() {
            document.getElementById('feedback-form').style.display = 'none';
            document.getElementById('search').value = '';
        }
    </script>
</body>
</html>