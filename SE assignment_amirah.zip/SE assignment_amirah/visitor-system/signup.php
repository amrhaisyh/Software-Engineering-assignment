<?php
    include 'config.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = $_POST['name'];
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm-password']; // Get confirm password

        // Check if the passwords match
        if ($password !== $confirm_password) {
            echo "<script>alert('Passwords do not match. Please try again.'); window.location.href='signup.php';</script>";
            exit();
        }

        // Hash password for security
        $hashed_password = $password;

        // Check if username or email already exists
        $check_query = "SELECT * FROM visitor WHERE username='$username' OR email='$email'";
        $result = mysqli_query($conn, $check_query);

        if (mysqli_num_rows($result) > 0) {
            echo "<script>alert('Username or email already exists.'); window.location.href='signup.php';</script>";
            exit();
        }

        // Insert new user into database
        $query = "INSERT INTO visitor (name, username, email, password) VALUES ('$name', '$username', '$email', '$hashed_password')";

        if (mysqli_query($conn, $query)) {
            echo "<script>alert('Account created successfully!'); window.location.href='login.php';</script>";
        } else {
            echo "<script>alert('Error creating account.'); window.location.href='signup.php';</script>";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            position: relative;
            overflow: hidden;
        }

        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('museum background.jpg') no-repeat center center fixed;
            background-size: cover;
            opacity: 0.7;
            z-index: -1;
        }

        .container {
            width: 350px;
            background: #ffffff;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
            z-index: 1;
        }

        .container img {
            width: 100px;
            margin-bottom: -10px;
        }

        .container h2 {
            margin-bottom: 10px;
            font-size: 18px;
            color: #333;
        }

        .form-group {
            margin-bottom: 15px;
            text-align: left;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .error-message {
            color: red;
            font-size: 12px;
            margin-top: 5px;
        }

        .btn {
            width: 100%;
            padding: 10px;
            border: none;
            background-color: #007bff;
            color: white;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

    <div class="container">
        <img src="logo.jpg" alt="Logo">
        <h2>Create Your Account Now</h2>
        <form id="signup-form" action="signup.php" method="POST">
            <div class="form-group">
                <input type="text" name="name" placeholder="Full Name" required>
            </div>
            <div class="form-group">
                <input type="text" name="username" placeholder="Username" required>
            </div>
            <div class="form-group">
                <input type="email" name="email" placeholder="Email" required>
            </div>
            <div class="form-group">
                <input type="password" name="password" id="password" placeholder="Password" required>
            </div>
            <div class="form-group">
                <input type="password" name="confirm-password" id="confirm-password" placeholder="Confirm Password" required>
                <div id="error-message" class="error-message"></div>
            </div>
            <p>Already have an account? <a href="login.php">Login Here</a></p>
            <button type="submit" class="btn">Create Account</button>
        </form>
    </div>

    <script>
        // JavaScript to validate the passwords match
        const passwordField = document.getElementById('password');
        const confirmPasswordField = document.getElementById('confirm-password');
        const errorMessage = document.getElementById('error-message');
        const form = document.getElementById('signup-form');

        form.addEventListener('submit', function(event) {
            if (passwordField.value !== confirmPasswordField.value) {
                errorMessage.textContent = 'Passwords do not match.';
                event.preventDefault(); // Prevent form submission
            } else {
                errorMessage.textContent = ''; // Clear error message if passwords match
            }
        });
    </script>

</body>
</html>
