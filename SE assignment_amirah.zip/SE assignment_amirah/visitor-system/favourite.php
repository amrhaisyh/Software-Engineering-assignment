<?php
    include 'config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Favourite | National Art Museum</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background: #f5f0e1;
        }

        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 20px;
            background-color: #f4f4f4;
            border-bottom: 1px solid #ccc;
        }

        header img {
            height: 60px;
        }

        nav {
            display: flex;
            gap: 15px;
        }

        nav a {
            text-decoration: none;
            color: #333;
            padding: 8px 15px;
            border: 1px solid transparent;
            border-radius: 5px;
        }

        nav a:hover {
            background-color: #ddd;
            border-color: #ccc;
        }

        /* Style for the active link */
        nav a.active {
            color: brown;
            font-weight: normal;
        }

        .search-bar {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .search-bar input {
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            padding: 10px;
            background-color: #f4f4f4;
        }
    </style>
</head>
<body>
    <header>
        <img src="logo.jpg" alt="National Art Museum Logo">
        <nav>
            <a href="home.php">Home</a>
            <a href="exhibit.php">Exhibit</a>
            <a href="event.php">Event</a>
            <a href="favourite.php" class="active">Favourite</a>
            <a href="feedback.php">Feedback</a>
            <a href="inquiry.php">Contact Us</a>
            <a href="profile.php">Profile</a>
        </nav>
        <div class="search-bar">
            <input type="text" placeholder="Search">
        </div>
    </header>

    <footer>
        &copy; 2025 National Art Museum. All rights reserved.
    </footer>
    
    <script>
        // Get all the navigation links
        const navLinks = document.querySelectorAll("nav a");

        // Add a click event listener to each link
        navLinks.forEach(link => {
            link.addEventListener("click", function () {
                // Remove the 'active' class from all links
                navLinks.forEach(nav => nav.classList.remove("active"));
                // Add the 'active' class to the clicked link
                this.classList.add("active");
            });
        });
    </script>
</body>
</html>
