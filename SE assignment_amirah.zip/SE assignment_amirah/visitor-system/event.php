<?php
    include 'config.php';

    // Fetch all events from the database
    $query = "SELECT * FROM event";
    $result = mysqli_query($conn, $query);

    // Check if any events are returned
    if (!$result) {
        die("Error retrieving events: " . mysqli_error($conn));
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event | National Art Museum</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background: #f5f0e1;
        }

        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 20px;
            background-color: #f4f4f4;
            border-bottom: 1px solid #ccc;
        }

        header img {
            height: 60px;
        }

        nav {
            display: flex;
            gap: 15px;
        }

        nav a {
            text-decoration: none;
            color: #333;
            padding: 8px 15px;
            border: 1px solid transparent;
            border-radius: 5px;
        }

        nav a:hover {
            background-color: #ddd;
            border-color: #ccc;
        }

        .search-bar {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .search-bar input {
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        
        nav a.active {
            color: brown;
            font-weight: normal;
        }

        footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            padding: 10px;
            background-color: #f4f4f4;
        }

        .events-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: flex-start; /* Align content to the left */
			align-items: left;
            gap: 20px;
            padding: 40px;
        }

        .event {
            width: 600px;
            margin: 10px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 20px;
            background-color: white;
            text-align: left;
        }

        .event img {
            width: 100%;
            height: auto;
            border-radius: 5px;
        }

        .event h3 {
            font-size: 1.2rem;
            color: #333;
            text-align: left;
        }

        .event p {
            font-size: 1rem;
            color: #666;
            text-align: left;
        }
    </style>
</head>
<body>
    <header>
        <img src="logo.jpg" alt="National Art Museum Logo">
        <nav>
            <a href="home.php">Home</a>
            <a href="exhibit.php">Exhibit</a>
            <a href="event.php" class="active">Event</a>
            <a href="favourite.php">Favourite</a>
            <a href="feedback.php">Feedback</a>
            <a href="inquiry.php">Contact Us</a>
            <a href="profile.php">Profile</a>
        </nav>
        <div class="search-bar">
            <input type="text" placeholder="Search">
        </div>
    </header>

    <div class="events-container">
        <?php
            while ($event = mysqli_fetch_assoc($result)) {
                echo "<div class='event'>";
                echo "<img src='" . $event['image'] . "' alt='Event Image'>";
                echo "<h3>" . $event['title'] . "</h3>";
                echo "<p><strong>Description:</strong> " . $event['description'] . "</p>";
                echo "<p><strong>Period:</strong> " . $event['period'] . "</p>";
                echo "</div>";
            }
        ?>
    </div>

    <footer>
        &copy; 2025 National Art Museum. All rights reserved.
    </footer>

    <script>
        const navLinks = document.querySelectorAll("nav a");
        navLinks.forEach(link => {
            link.addEventListener("click", function () {
                navLinks.forEach(nav => nav.classList.remove("active"));
                this.classList.add("active");
            });
        });
    </script>
</body>
</html>

<?php
    mysqli_close($conn);
?>
