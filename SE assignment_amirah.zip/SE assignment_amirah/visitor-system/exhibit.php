<?php
    include 'config.php';

    // Fetch all exhibits from the database
    $query = "SELECT * FROM exhibit";
    $result = mysqli_query($conn, $query);

    // Check if any exhibits are returned
    if (!$result) {
        die("Error retrieving exhibits: " . mysqli_error($conn));
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exhibit | National Art Museum</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background: #f5f0e1;
        }

        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 20px;
            background-color: #f4f4f4;
            border-bottom: 1px solid #ccc;
        }

        header img {
            height: 60px;
        }

        nav {
            display: flex;
            gap: 15px;
        }

        nav a {
            text-decoration: none;
            color: #333;
            padding: 8px 15px;
            border: 1px solid transparent;
            border-radius: 5px;
        }

        nav a:hover {
            background-color: #ddd;
            border-color: #ccc;
        }

        .search-bar {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .search-bar input {
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        /* Style for the active link */
        nav a.active {
            color: brown;
            font-weight: normal;
        }

        footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            padding: 10px;
            background-color: #f4f4f4;
        }

        /* Styles for exhibits */
        .exhibits-container {
            display: flex;
            flex-wrap: wrap;
            flex-direction: column; /* Stack exhibits vertically */
            align-items: left;
            justify-content: space-around;
            gap: 3px;
            padding: 40px;
        }

        .exhibit {
            width: 600px; /* Adjust width as needed */
            margin: 10px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 20px;
            background-color: white;
            text-align: left;
        }

        .exhibit img {
            width: 100%;
            height: auto;
            border-radius: 5px;
        }

        .exhibit h3 {
            font-size: 1.2rem;
            color: #333;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .exhibit p {
            font-size: 1rem;
            color: #666;
            text-align: left;
        }

        .rating {
            margin-top: 10px;
            font-weight: bold;
            color: #f39c12;
        }

        /* Favorite (Heart) Button */
        .favorite-btn {
            background: none;
            border: none;
            font-size: 2.5rem;
            cursor: pointer;
            color: #999; /* Default empty heart color */
        }

        .favorite-btn.active {
            color: red; /* Filled heart when active */
        }
    </style>
</head>
<body>
    <header>
        <img src="logo.jpg" alt="National Art Museum Logo">
        <nav>
            <a href="home.php">Home</a>
            <a href="exhibit.php" class="active">Exhibit</a>
            <a href="event.php">Event</a>
            <a href="favourite.php">Favourite</a>
            <a href="feedback.php">Feedback</a>
            <a href="inquiry.php">Contact Us</a>
            <a href="profile.php">Profile</a>
        </nav>
        <div class="search-bar">
            <input type="text" placeholder="Search">
        </div>
    </header>

    <div class="exhibits-container">
        <?php
            // Loop through all the exhibits and display them
            while ($exhibit = mysqli_fetch_assoc($result)) {
                // Check if the image path exists in the database and append a default image if not
                $imagePath = !empty($exhibit['image']) ? $exhibit['image'] : 'images/default.jpg'; 
                
                echo "<div class='exhibit'>";
                echo "<img src='$imagePath' alt='Exhibit Image'>";
                echo "<h3>" . $exhibit['title'];
                echo " <button class='favorite-btn' onclick='toggleFavorite(this)'>&#9825;</button>"; // Empty heart (♡)
                echo "</h3>";
                echo "<p><strong>Category:</strong> " . $exhibit['category'] . "</p>";
                echo "<p><strong>Description:</strong> " . $exhibit['description'] . "</p>";
                echo "<p class='rating'><strong>Rating:</strong> " . $exhibit['rating'] . "/5</p>";
                echo "</div>";
            }
        ?>
    </div>

    <footer>
        &copy; 2025 National Art Museum. All rights reserved.
    </footer>

    <script>
        function toggleFavorite(button) {
            if (button.classList.contains("active")) {
                button.classList.remove("active");
                button.innerHTML = "&#9825;"; // Empty heart (♡)
            } else {
                button.classList.add("active");
                button.innerHTML = "&#10084;"; // Filled heart (❤️)
            }
        }
    </script>
</body>
</html>

<?php
    // Close the database connection
    mysqli_close($conn);
?>
