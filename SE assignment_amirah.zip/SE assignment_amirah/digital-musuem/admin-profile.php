<?php
include "config.php";

if (isset($_POST['submit'])) {
  // Get form data
  $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
  $username = mysqli_real_escape_string($conn, $_POST['username']);
  $email = mysqli_real_escape_string($conn, $_POST['email']);
  $password = mysqli_real_escape_string($conn, $_POST['password']);
  $user_role = $_SESSION['role']; // Staff or Admin


  // Depending on user role (Staff or Admin), update the correct table
  if ($user_role === 'Staff') {
    $sql = "UPDATE staff SET name = '$full_name', username = '$username', email = '$email', password = '$password' WHERE staffID = '{$_SESSION['staffID']}'";
  } else if ($user_role === 'Admin') {
    $sql = "UPDATE admin SET name = '$full_name', username = '$username', email = '$email' password = '$password' WHERE adminID = '{$_SESSION['adminID']}'";
  } else {
    echo "<script>alert('Invalid user role.');</script>";
    exit;
  }

  // Execute SQL query
  if (mysqli_query($conn, $sql)) {
    // Update session variables after successful update
    $_SESSION['name'] = $full_name;
    $_SESSION['username'] = $username;
    $_SESSION['email'] = $email;

    // Redirect back to profile or dashboard
    echo "<script>alert('Profile updated successfully!');</script>";
    echo "<script>window.location.href = 'admin-profile.php';</script>";
  } else {
    echo "<script>alert('Error updating profile. Please try again.');</script>";
  }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="icon" type="image/png" href="assets/logo.svg" />
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
  <title>SadaqahTrack</title>
  <style>
    body {
      font-family: 'Montserrat', sans-serif;
    }

    .bground-blue {
      background-color: #0097B2;
    }

    .sblue {
      color: #0097B2;
    }

    /* Style the progress bar fill */
    progress::-webkit-progress-value {
      background-color: #0097B2;
      /* Change the fill color to green */
    }
  </style>
</head>

<body class="bg-slate-200">

  <!-- Navigation Bar -->
  <section class="relative">
    <nav class="bg-white flex flex-row gap-x-5 shadow-xl py-3 px-10">
      <div class="flex gap-x-4  ml-5">
        <img style="height: 80px;" src="assets/logo-museum.png" alt="">
        <h1 class="sblue font-bold text-2xl my-auto">National Art Museum</h1>
      </div>
    </nav>
  </section>

  <section class="flex p-10 gap-x-5 h-full">
    <div class="w-[250px]">
      <div class="flex flex-col bg-white p-5 rounded-2xl">
        <svg class="w-20 mx-auto" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
          <path
            d="M399 384.2C376.9 345.8 335.4 320 288 320H224c-47.4 0-88.9 25.8-111 64.2c35.2 39.2 86.2 63.8 143 63.8s107.8-24.7 143-63.8zM0 256a256 256 0 1 1 512 0A256 256 0 1 1 0 256zm256 16a72 72 0 1 0 0-144 72 72 0 1 0 0 144z" />
        </svg>
        <h1 class="text-lg  text-center mt-5">
          <?php echo $_SESSION['role']; ?>
        </h1>
        <h1 class="text-sm  text-center">
          <?php echo $_SESSION['name']; ?>
        </h1>
        <hr class="border-1 border-black my-5">
        <a class="flex mb-4" href="admin-exhibits.php">
          <div class="w-10 mr-auto my-auto">
          </div>
          <h1 class="w-full">Exhibit</h1>
        </a>
        <a class="flex mb-4" href="admin-event.php">
          <div class="w-9 ml-0.5 mr-auto my-auto">
          </div>
          <h1 class="w-full">Event</h1>
        </a>
        <a class="flex mb-4" href="admin-inquiries.php">
          <div class="w-9 ml-0.5 mr-auto my-auto">
          </div>
          <h1 class="w-full">Inquiries</h1>
        </a>
        <a class="flex mb-4" href="admin-visitors.php">
          <div class="w-9 ml-0.5 mr-auto my-auto">
          </div>
          <h1 class="w-full">Visitor</h1>
        </a>
        <?php
        if (isset($_SESSION['adminID']) && isset($_SESSION['role']) && $_SESSION['role'] == 'Admin') {
          echo '
            <a class="flex mb-4" href="admin-staff.php">
                <div class="w-9 ml-0.5 mr-auto my-auto"></div>
                <h1 class="w-full">Staff</h1>
            </a>';
        }
        ?>
        <a class="flex mb-4" href="admin-feedback.php">
          <div class="w-9 ml-0.5 mr-auto my-auto">
          </div>
          <h1 class="w-full">Feedback</h1>
        </a>
        <a class="flex mb-32" href="admin-summary.php">
          <div class="w-9 ml-1 mr-auto my-auto">
          </div>
          <h1 class="w-full">Summary</h1>
        </a>
        <hr class="border-1 border-black my-5">
        <a class="flex mb-3  " href="admin-profile.php">
          <div class="w-9 ml-1 mr-auto my-auto">
          </div>
          <h1 class="w-full">Profile</h1>
        </a>
        <?php
        if (isset($_SESSION['adminID']) && isset($_SESSION['role']) && $_SESSION['role'] == 'Admin') {
          echo '
          <a class="flex mb-3" href="admin-access.php">
              <div class="w-9 ml-1 mr-auto my-auto">
              </div>
              <h1 class="w-full">Configuration</h1>
          </a>
          ';
        } else {
          echo '
          <a class="flex mb-3" href="troubleshoot.php">
              <div class="w-9 ml-1 mr-auto my-auto">
              </div>
              <h1 class="w-full">Troubleshoot</h1>
          </a>
          ';
        }
        ?>
        <a class="flex mb-10" href="logout.php">
          <div class="w-9 ml-1 mr-auto my-auto">
          </div>
          <h1 class="w-full">Log Out</h1>
        </a>

      </div>

    </div>
    <div class="w-full h-full">
      <div class="ml-[100px] bg-white rounded-xl p-6 shadow-md w-[800px]">
        <h1 class="text-2xl font-bold text-gray-800 mb-4 text-center">Profile</h1>
        <hr class="border-gray-300 mb-4">

        <!-- Profile Picture -->
        <div class="flex flex-col items-center mb-6">
          <svg class="w-20 mx-auto" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
            <path
              d="M399 384.2C376.9 345.8 335.4 320 288 320H224c-47.4 0-88.9 25.8-111 64.2c35.2 39.2 86.2 63.8 143 63.8s107.8-24.7 143-63.8zM0 256a256 256 0 1 1 512 0A256 256 0 1 1 0 256zm256 16a72 72 0 1 0 0-144 72 72 0 1 0 0 144z" />
          </svg>
        </div>

        <!-- Profile Form -->
        <form class="flex flex-col items-center" method="POST" action="">
          <div class="w-full flex flex-col items-center">
            <!-- Name -->
            <div class="mb-4 w-full max-w-[500px]">
              <label class="block text-gray-700 font-semibold mb-1">Full Name</label>
              <input type="text" name="full_name" class="w-full p-3 border rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
                placeholder="Enter full name" value="<?php echo isset($_SESSION['name']) ? $_SESSION['name'] : ''; ?>" required>
            </div>

            <!-- Username -->
            <div class="mb-4 w-full max-w-[500px]">
              <label class="block text-gray-700 font-semibold mb-1">Username</label>
              <input type="text" name="username" class="w-full p-3 border rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
                placeholder="Enter username" value="<?php echo isset($_SESSION['username']) ? $_SESSION['username'] : ''; ?>" required>
            </div>

            <!-- Email -->
            <div class="mb-4 w-full max-w-[500px]">
              <label class="block text-gray-700 font-semibold mb-1">Email</label>
              <input type="email" name="email" class="w-full p-3 border rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
                placeholder="Enter email" value="<?php echo isset($_SESSION['email']) ? $_SESSION['email'] : ''; ?>" required>
            </div>

            <!-- Password -->
            <div class="mb-4 w-full max-w-[500px]">
              <label class="block text-gray-700 font-semibold mb-1">Password</label>
              <input type="password" name="password" class="w-full p-3 border rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
                placeholder="Enter new password">
            </div>

            <!-- Save Button -->
            <button type="submit" name="submit" class="w-full max-w-[500px] bg-blue-500 text-white font-bold py-3 rounded-lg shadow-md hover:bg-blue-600 transition duration-200">
              Save Changes
            </button>
          </div>
        </form>




      </div>

  </section>

</body>

</html>