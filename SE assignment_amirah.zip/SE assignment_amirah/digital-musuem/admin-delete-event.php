<?php
include "config.php";

$eventID = $_GET['id'];

$sql = "DELETE FROM EVENT WHERE eventID = '$eventID'";

if (mysqli_query($conn, $sql)) {
    mysqli_close($conn);
    echo "<script>alert('The selected Event has been deleted!');</script>";
    echo "<script>window.location.href = 'admin-event.php';</script>";

    exit;
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}
?>
