<?php
include "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = intval($_POST["issue_id"]);
    $status = mysqli_real_escape_string($conn, $_POST["status"]);

    $sql = "UPDATE Troubleshoot SET status='$status' WHERE troubleshootID=$id";
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Status updated successfully');</script>";
        echo "<script>window.location.href = 'admin-configure-troubleshoot.php';</script>";  // Redirect to your page
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
