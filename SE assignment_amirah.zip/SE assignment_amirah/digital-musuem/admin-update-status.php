<?php
include "config.php";

// Assuming the connection is already established
if (isset($_POST['inquiryID']) && isset($_POST['status'])) {
    $inquiryID = mysqli_real_escape_string($conn, $_POST['inquiryID']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

    // Update the status in the database
    $sql = "UPDATE inquiry SET status = '$status' WHERE inquiryID = '$inquiryID'";

    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Status updated successfully');</script>";
        echo "<script>window.location.href = 'admin-inquiries.php';</script>";  // Redirect to your page
    } else {
        echo "<script>alert('Failed to update status');</script>";
    }
}
