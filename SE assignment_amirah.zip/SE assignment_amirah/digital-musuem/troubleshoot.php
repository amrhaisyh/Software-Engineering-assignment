<?php
include "config.php";


if (isset($_POST['submit'])) {
    // Escape inputs to prevent SQL injection
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $date = mysqli_real_escape_string($conn, $_POST['date']);

    // Validate and format date
    $dateObject = DateTime::createFromFormat('Y-m-d', $date);
    if (!$dateObject) {
        echo "<script>alert('Invalid date format. Please enter a valid date.');</script>";
        exit;
    }
    $formatted_date = $dateObject->format('Y-m-d');

    // Handle file upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $image_name = basename($_FILES['image']['name']);
        $image_tmp = $_FILES['image']['tmp_name'];
        $upload_path = "uploads/" . $image_name;

        // Ensure the uploads folder exists
        if (!file_exists('uploads')) {
            mkdir('uploads', 0777, true);
        }

        // Move uploaded file
        if (move_uploaded_file($image_tmp, $upload_path)) {
            // Insert into database using prepared statements
            $stmt = $conn->prepare("INSERT INTO `Troubleshoot`(`staffID`, `title`, `description`, `date`, `image`) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("issss", $_SESSION['staffID'], $title, $description, $formatted_date, $upload_path);

            if ($stmt->execute()) {
                echo "<script>alert('New Troubleshoot has been submitted!');</script>";
                echo "<script>window.location.href = 'troubleshoot.php';</script>";
            } else {
                echo "<script>alert('Database Insertion Failed');</script>";
            }
        } else {
            echo "<script>alert('File Upload Failed');</script>";
        }
    } else {
        echo "<script>alert('Please upload a valid image');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="icon" type="image/png" href="assets/logo-title.jpg" />
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet">
    <title>National Art Museum</title>
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
        }

        .bground-blue {
            background-color: #0097B2;
        }

        .sblue {
            color: #0097B2;
        }

        /* Style the progress bar fill */
        progress::-webkit-progress-value {
            background-color: #0097B2;
            /* Change the fill color to green */
        }

        .popup {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.4);
            width: 400px;
            /* Increased size */
            max-width: 90%;
        }

        .popup.active {
            display: block;
        }

        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            /* Darker transparency */
            backdrop-filter: blur(5px);
            /* Adds a slight blur effect */
        }

        .overlay.active {
            display: block;
        }

        .popup input,
        .popup textarea,
        .popup select {
            width: 100%;
            margin: 8px 0;
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .popup button {
            margin-top: 15px;
            padding: 10px;
            width: 100%;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-submit {
            background: #007bff;
            color: white;
        }

        .btn-cancel {
            background: #ccc;
            margin-top: 5px;
        }
    </style>
</head>

<body class="bg-slate-200">



    <section class="relative">
        <nav class="bg-white flex flex-row gap-x-5 shadow-xl py-3 px-10">
            <div class="flex gap-x-4  ml-5">
                <img style="height: 80px;" src="assets/logo-museum.png" alt="">
                <h1 class="sblue font-bold text-2xl my-auto">National Art Museum</h1>
            </div>
        </nav>
    </section>

    <section class="flex p-10 gap-x-5 h-full">
        <div class="w-[250px]">
            <div class="flex flex-col bg-white p-5 rounded-2xl">
                <svg class="w-20 mx-auto" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                    <path
                        d="M399 384.2C376.9 345.8 335.4 320 288 320H224c-47.4 0-88.9 25.8-111 64.2c35.2 39.2 86.2 63.8 143 63.8s107.8-24.7 143-63.8zM0 256a256 256 0 1 1 512 0A256 256 0 1 1 0 256zm256 16a72 72 0 1 0 0-144 72 72 0 1 0 0 144z" />
                </svg>
                <h1 class="text-lg  text-center mt-5">
                    <?php echo $_SESSION['role']; ?>
                </h1>
                <h1 class="text-sm  text-center">
                    <?php echo $_SESSION['name']; ?>
                </h1>
                <hr class="border-1 border-black my-5">
                <a class="flex mb-4" href="admin-exhibits.php">
                    <div class="w-10 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Exhibit</h1>
                </a>
                <a class="flex mb-4" href="admin-event.php">
                    <div class="w-9 ml-0.5 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Event</h1>
                </a>
                <a class="flex mb-4" href="admin-inquiries.php">
                    <div class="w-9 ml-0.5 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Inquiries</h1>
                </a>
                <a class="flex mb-4" href="admin-visitors.php">
                    <div class="w-9 ml-0.5 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Visitor</h1>
                </a>
                <?php
                if (isset($_SESSION['adminID']) && isset($_SESSION['role']) && $_SESSION['role'] == 'Admin') {
                    echo '
                    <a class="flex mb-4" href="admin-staff.php">
                        <div class="w-9 ml-0.5 mr-auto my-auto"></div>
                        <h1 class="w-full">Staff</h1>
                    </a>';
                }
                ?>
                <a class="flex mb-4" href="admin-feedback.php">
                    <div class="w-9 ml-0.5 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Feedback</h1>
                </a>
                <a class="flex mb-32" href="admin-summary.php">
                    <div class="w-9 ml-1 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Summary</h1>
                </a>
                <hr class="border-1 border-black my-5">
                <a class="flex mb-3" href="admin-profile.php">
                    <div class="w-9 ml-1 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Profile</h1>
                </a>
                <?php
                if (isset($_SESSION['adminID']) && isset($_SESSION['role']) && $_SESSION['role'] == 'Admin') {
                    echo '
                    <a class="flex mb-3" href="admin-access.php">
                        <div class="w-9 ml-1 mr-auto my-auto">
                        </div>
                        <h1 class="w-full">Configuration</h1>
                    </a>
                    ';
                } else {
                    echo '
                    <a class="flex mb-3 sblue font-semibold" href="troubleshoot.php">
                        <div class="w-9 ml-1 mr-auto my-auto">
                        </div>
                        <h1 class="w-full">Troubleshoot</h1>
                    </a>
                    ';
                }
                ?>
                <a class="flex mb-10" href="logout.php">
                    <div class="w-9 ml-1 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Log Out</h1>
                </a>

            </div>

        </div>
        <div class="w-full h-full">
            <div class="bg-white rounded-2xl h-full">
                <div class="flex">
                    <h1 class="text-2xl font-semibold p-5">Troubleshoot Submitted</h1>
                    <button id="newTroubleshootBtn" class="bg-blue-500 text-white rounded-xl py-2 px-5 my-auto text-sm">
                        New Troubleshoot
                    </button>
                    <!-- Popup Modal -->
                    <div id="newTroubleshootModal" class="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center hidden">
                        <div class="bg-white p-8 rounded-2xl shadow-xl w-full max-w-lg">
                            <h2 class="text-2xl font-bold text-gray-800 mb-6">New Troubleshoot Details</h2>
                            <form id="newTroubleshootForm" class="space-y-4" method="POST" action="" enctype="multipart/form-data">
                                <div>
                                    <label for="title" class="block text-sm font-medium text-gray-700">Title</label>
                                    <input type="text" id="title" name="title" placeholder="Enter the title"
                                        class="mt-2 block w-full border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm p-3">
                                </div>
                                <div>
                                    <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
                                    <textarea id="description" name="description" rows="4" placeholder="Write a description"
                                        class="mt-2 block w-full border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm p-3"></textarea>
                                </div>
                                <div>
                                    <label for="date" class="block text-sm font-medium text-gray-700">Date</label>
                                    <input type="date" id="date" name="date"
                                        class="mt-2 block w-full border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm p-3">
                                </div>
                                <div>
                                    <label for="image" class="block text-sm font-medium text-gray-700">Image</label>
                                    <input type="file" id="image" name="image" accept="image/*"
                                        class="mt-2 block w-full text-sm text-gray-700 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500">
                                </div>
                                <div class="flex justify-end space-x-3">
                                    <button type="button" id="cancelBtn"
                                        class="px-6 py-2 bg-gray-300 text-gray-700 rounded-lg shadow hover:bg-gray-400">
                                        Cancel
                                    </button>
                                    <button type="submit" name="submit"
                                        class="px-6 py-2 bg-gradient-to-r from-blue-500 to-green-500 text-white rounded-lg shadow-lg hover:from-blue-600 hover:to-green-600 focus:ring-4 focus:ring-blue-300">
                                        Submit
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <hr class="border-gray-300 mb-6">
                <div class=" p-5 ">
                    <table class="w-full mt-5 border-collapse">
                        <thead>
                            <tr class="bg-gray-200">
                                <th class="p-2 text-s">No</th>
                                <th class="p-2 text-s">Title</th>
                                <th class="p-2 text-s">Date</th>
                                <th class="p-2 text-s">Status</th>
                                <th class="p-2 text-s">Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- PHP - Fetch Data -->
                            <?php
                            $sql = "SELECT * FROM Troubleshoot WHERE staffID = '" . $_SESSION['staffID'] . "';";
                            $result = mysqli_query($conn, $sql);

                            $count = 1;
                            if ($result && mysqli_num_rows($result) > 0) {
                                while ($row = mysqli_fetch_assoc($result)) {
                                    // Split datetime into date format
                                    $date = DateTime::createFromFormat('Y-m-d', $row['date'])->format('d/m/y');

                                    echo '
                                    <tr class="bg-white">
                                        <td class="p-2 border text-s text-center">' . $count . '</td>
                                        <td class="p-2 border text-s text-center">' . htmlspecialchars($row['title']) . '</td>
                                        <td class="p-2 border text-s text-center">' . $date . '</td>
                                        <td class="p-2 border text-s text-center font-semibold ' .
                                        (($row['status'] === 'In Progress') ? 'text-red-500' : 'text-green-500') . '">
                                            ' . htmlspecialchars($row['status']) . '
                                        </td>
                                        <td class="p-2 border text-s text-center">
                                            <button class="bg-blue-500 text-white px-4 py-2 rounded" 
                                                onclick="openPopup(
                                                    \'' . addslashes($row['troubleshootID']) . '\', 
                                                    \'' . addslashes($row['title']) . '\', 
                                                    \'' . addslashes($row['image']) . '\', 
                                                    \'' . addslashes($date) . '\', 
                                                    \'' . addslashes($row['description']) . '\',
                                                    \'' . addslashes($row['status']) . '\'
                                                )">
                                                <span style="font-size:15px">View</span>
                                            </button>
                                        </td>
                                    </tr>';
                                    $count++;
                                }
                            } else {
                                echo '<tr><td colspan="6" class="text-center">No records found.</td></tr>';
                            }
                            ?>

                        </tbody>
                    </table>
                </div>
                <div class="overlay" id="overlay"></div>

                <div id="feedbackPopup" class="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center hidden">
                    <div class="bg-white p-5 rounded-xl w-1/3">
                        <h2 class="text-xl font-bold mb-4">Troubleshoot Details</h2>
                        <hr class="border-1 border-black mb-4">
                        <p class="mb-2"><strong>Title:</strong> <span id="popupTitle"></span></p>
                        <p class="mb-2"><strong>Date:</strong> <span id="popupDate"></span></p>
                        <p class="mb-2"><strong>Description:</strong> <span id="popupDescription"></span></p>
                        <p class="mb-4"><strong>Status:</strong>: <span id="popupStatus"></span></p>

                        <img style="margin-left:40px; height:350px; width:400px;" id="popupImage" src="" alt="Feedback Image" class="w-full h-auto rounded-lg hidden"><br>

                        <div class="flex justify-end space-x-2 mt-4">
                            <button onclick="closePopup()" class="bg-gray-500 text-white px-4 py-2 rounded">Close</button>
                        </div>
                    </div>
                </div>

                <script>
                    function openPopup(id, title, image, date, description, status) {
                        document.getElementById("popupTitle").textContent = title;
                        document.getElementById("popupDate").textContent = date;
                        document.getElementById("popupDescription").textContent = description;

                        var imgElement = document.getElementById("popupImage");
                        if (image) {
                            imgElement.src = image;
                            imgElement.classList.remove("hidden");
                        } else {
                            imgElement.classList.add("hidden");
                        }

                        // Display the status in the popup
                        document.getElementById("popupStatus").textContent = status;

                        document.getElementById("feedbackPopup").classList.remove("hidden");
                    }

                    function closePopup() {
                        document.getElementById("feedbackPopup").classList.add("hidden");
                    }

                    // JavaScript to handle popup functionality
                    const newTroubleshootBtn = document.getElementById('newTroubleshootBtn');
                    const newTroubleshootModal = document.getElementById('newTroubleshootModal');
                    const cancelBtn = document.getElementById('cancelBtn');

                    newTroubleshootBtn.addEventListener('click', () => {
                        newTroubleshootModal.classList.remove('hidden');
                    });

                    cancelBtn.addEventListener('click', () => {
                        newTroubleshootModal.classList.add('hidden');
                    });
                </script>
            </div>

    </section>

</body>

</html>