<?php
include "config.php";


// Check if the user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
  header("Location: login.php");
  exit();
}

// Check if an announcement exists in the session
if (isset($_SESSION['announcement'])) {
  $announcement = $_SESSION['announcement'];
  unset($_SESSION['announcement']); // Remove announcement after showing it
}

if (isset($_POST['submit'])) {
  // Escape inputs to prevent SQL injection
  $title = mysqli_real_escape_string($conn, $_POST['title']);
  $description = mysqli_real_escape_string($conn, $_POST['description']);
  $category = mysqli_real_escape_string($conn, $_POST['category']);

  // Handle file upload
  if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
    $image_name = basename($_FILES['image']['name']); // Secure file name
    $image_tmp = $_FILES['image']['tmp_name'];
    $upload_path = "uploads/" . $image_name; // Ensure correct path

    // Ensure the uploads folder exists
    if (!file_exists('uploads')) {
      mkdir('uploads', 0777, true);
    }

    // Move uploaded file
    if (move_uploaded_file($image_tmp, $upload_path)) {
      // Insert into database
      $sql = "INSERT INTO `exhibit`(`title`, `description`, `category`, `image`, `rating`)
                    VALUES ('$title', '$description', '$category', '$upload_path', 0.0)";

      $result = mysqli_query($conn, $sql);

      if ($result) {
        echo "<script>alert('New Exhibit has been added!');</script>";
        echo "<script>window.location.href = 'admin-exhibits.php';</script>";
      } else {
        echo "<script>alert('Database Insertion Failed');</script>";
      }
    } else {
      echo "<script>alert('File Upload Failed');</script>";
    }
  } else {
    echo "<script>alert('Please upload a valid image');</script>";
  }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="icon" type="image/png" href="assets/logo-title.jpg" />
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap"
    rel="stylesheet">
  <title>National Art Museum</title>
  <style>
    body {
      font-family: 'Montserrat', sans-serif;
    }

    .bground-blue {
      background-color: #0097B2;
    }

    .sblue {
      color: #0097B2;
    }

    /* Style the progress bar fill */
    progress::-webkit-progress-value {
      background-color: #0097B2;
      /* Change the fill color to green */
    }

    .popup {
      display: none;
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.4);
      width: 400px;
      /* Increased size */
      max-width: 90%;
    }

    .popup.active {
      display: block;
    }

    .overlay {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.7);
      /* Darker transparency */
      backdrop-filter: blur(5px);
      /* Adds a slight blur effect */
    }

    .overlay.active {
      display: block;
    }

    .popup input,
    .popup textarea,
    .popup select {
      width: 100%;
      margin: 8px 0;
      padding: 10px;
      font-size: 14px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    .popup button {
      margin-top: 15px;
      padding: 10px;
      width: 100%;
      font-size: 16px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .btn-submit {
      background: #007bff;
      color: white;
    }

    .btn-cancel {
      background: #ccc;
      margin-top: 5px;
    }

    .custom-popup {
      display: none;
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background-color: #fff;
      border-radius: 10px;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
      padding: 20px;
      width: 400px;
      z-index: 9999;
    }

    .custom-popup-content {
      text-align: center;
    }

    .popup-actions {
      margin-top: 20px;
    }

    .btn-confirm {
      background-color: #007bff;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .btn-confirm:hover {
      background-color: #0056b3;
    }

    .announcement-popup {
      display: none;
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.4);
      width: 400px;
      max-width: 90%;
      text-align: center;
      z-index: 1000;
    }

    .announcement-overlay {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.7);
      backdrop-filter: blur(5px);
      z-index: 999;
    }

    .announcement-popup button {
      margin-top: 15px;
      padding: 10px;
      width: 100%;
      font-size: 16px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      background: #007bff;
      color: white;
    }
  </style>
</head>

<body class="bg-slate-200">



  <!-- Navigation Bar -->
  <section class="relative">
    <nav class="bg-white flex flex-row gap-x-5 shadow-xl py-3 px-10">
      <div class="flex gap-x-4  ml-5">
        <img style="height: 80px;" src="assets/logo-museum.png" alt="">
        <h1 class="sblue font-bold text-2xl my-auto">National Art Museum</h1>
      </div>
    </nav>
  </section>

  <section class="flex p-10 gap-x-5 h-full">
    <div class="w-[250px] h-full">
      <div class="flex flex-col bg-white p-5 rounded-2xl">
        <svg class="w-20 mx-auto" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
          <path
            d="M399 384.2C376.9 345.8 335.4 320 288 320H224c-47.4 0-88.9 25.8-111 64.2c35.2 39.2 86.2 63.8 143 63.8s107.8-24.7 143-63.8zM0 256a256 256 0 1 1 512 0A256 256 0 1 1 0 256zm256 16a72 72 0 1 0 0-144 72 72 0 1 0 0 144z" />
        </svg>
        <h1 class="text-lg  text-center mt-5">
          <?php echo $_SESSION['role']; ?>
        </h1>
        <h1 class="text-sm  text-center">
          <?php echo $_SESSION['name']; ?>
        </h1>

        <hr class="border-1 border-black my-5">
        <a class="flex mb-4" href="admin-exhibits.php">
          <div class="w-10 mr-auto my-auto">
          </div>
          <h1 class="w-full sblue font-semibold">Exhibit</h1>
        </a>
        <a class="flex mb-4" href="admin-event.php">
          <div class="w-9 ml-0.5 mr-auto my-auto">
          </div>
          <h1 class="w-full">Event</h1>
        </a>
        <a class="flex mb-4" href="admin-inquiries.php">
          <div class="w-9 ml-0.5 mr-auto my-auto">
          </div>
          <h1 class="w-full">Inquiries</h1>
        </a>
        <a class="flex mb-4" href="admin-visitors.php">
          <div class="w-9 ml-0.5 mr-auto my-auto">
          </div>
          <h1 class="w-full">Visitor</h1>
        </a>
        <?php
        if (isset($_SESSION['adminID']) && isset($_SESSION['role']) && $_SESSION['role'] == 'Admin') {
          echo '
          <a class="flex mb-4" href="admin-staff.php">
              <div class="w-9 ml-0.5 mr-auto my-auto"></div>
              <h1 class="w-full">Staff</h1>
          </a>';
        }
        ?>
        <a class="flex mb-4" href="admin-feedback.php">
          <div class="w-9 ml-0.5 mr-auto my-auto">
          </div>
          <h1 class="w-full">Feedback</h1>
        </a>
        <a class="flex mb-32" href="admin-summary.php">
          <div class="w-9 ml-1 mr-auto my-auto">
          </div>
          <h1 class="w-full">Summary</h1>
        </a>
        <hr class="border-1 border-black my-5">
        <a class="flex mb-3" href="admin-profile.php">
          <div class="w-9 ml-1 mr-auto my-auto">
          </div>
          <h1 class="w-full">Profile</h1>
        </a>
        <?php
        if (isset($_SESSION['adminID']) && isset($_SESSION['role']) && $_SESSION['role'] == 'Admin') {
          echo '
            <a class="flex mb-3" href="admin-access.php">
                <div class="w-9 ml-1 mr-auto my-auto">
                </div>
                <h1 class="w-full">Configuration</h1>
            </a>
            ';
        } else {
          echo '
          <a class="flex mb-3" href="troubleshoot.php">
              <div class="w-9 ml-1 mr-auto my-auto">
              </div>
              <h1 class="w-full">Troubleshoot</h1>
          </a>
          ';
        }
        ?>
        <a class="flex mb-10" href="logout.php">
          <div class="w-9 ml-1 mr-auto my-auto">
          </div>
          <h1 class="w-full">Log Out</h1>
        </a>
      </div>

    </div>
    <div class="w-full h-[740px] overflow-y-auto bg-white rounded-2xl ">
      <div class="">
        <div class="flex">
          <h1 class="text-2xl font-semibold p-5">Exhibits</h1>
          <button style="background-color: #0097B2;" id="openPopup"
            class="bg-blue text-white rounded-xl py-2 px-5 my-auto text-sm">ADD NEW
            EXHIBIT</button>

        </div>

        <hr class="border-gray-300 mb-6">
        <div class="w-full p-5">
          <div class="grid grid-cols-3 gap-10">

            <!-- PHP -->
            <?php
            $sql = "SELECT * FROM exhibit";
            $result = mysqli_query($conn, $sql);

            if ($result && mysqli_num_rows($result) > 0) {
              while ($row = mysqli_fetch_assoc($result)) {
                echo '
                <div class="bg-white w-[400px] rounded-xl shadow-md">
                  <img style="height: 320px; width: 100%; object-fit: cover; display: block; margin: auto;" 
                       class="rounded-t-xl" 
                       src="' . $row['image'] . '" 
                       alt="">
                  <div class="p-5">
                    <h1 class="font-bold my-2">' . $row['title'] . '</h1>
                    <h1 class="my-4 text-sm">Category: ' . $row['category'] . '</h1>
                    <h1 class="my-4 text-sm">' . $row['description'] . '</h1>
                    <div class="flex my-2 justify-between">
                      <div class="flex">
                        <h1 class="mr-1 text-xs my-auto font-semibold ">Rating: <span style="color:red">' . $row['rating'] . '</span> / 10</h1>
                      </div>
                      <div class="flex items-center">
                        <a href="admin-delete-exhibit.php?id=' . $row['exhibitID'] . '" 
                          onclick="return confirm(\'Are you sure you want to delete this item?\');" >
                          <img style="height: 30px; width: 30px; object-fit: cover; display: block; margin: auto;"  class="rounded-t-xl" src="assets/delete.png" alt="">
                        </a>
                      </div>
                    </div>
                  </div>
                </div>';
              }
            }


            ?>


            <!-- POPUP -->
            <div class="overlay" id="overlay"></div>

            <div class="popup" id="popup">
              <h2>Add New Exhibit</h2>
              <form action="" method="POST" enctype="multipart/form-data">
                <input type="text" name="title" placeholder="Title">
                <textarea name="description" placeholder="Description"></textarea>
                <select name="category">
                  <option value="">Select Category</option>
                  <option value="Art">Art</option>
                  <option value="History">History</option>
                  <option value="Science">Science</option>
                </select>
                <input type="file" name="image">
                <button type="submit" class="btn-submit" name="submit">Submit</button>
                <button type="button" id="closePopup" class="btn-cancel">Cancel</button>
              </form>
            </div>

            <!-- ANNOUNCEMENT -->
            <?php if (!empty($announcement)): ?>
              <div class="announcement-overlay" id="announcementOverlay"></div>

              <div class="announcement-popup" id="announcementPopup">
                <h2 class="font-bold text-lg text-red-500"><?php echo htmlspecialchars($announcement['title']); ?></h2>
                <p class="my-2"><?php echo nl2br(htmlspecialchars($announcement['description'])); ?></p>
                <p class="text-gray-500 text-sm">Posted on: <?php echo date("F j, Y, g:i A", strtotime($announcement['datetime'])); ?></p>
                <button onclick="closeAnnouncementPopup()">OK</button>
              </div>

              <script>
                document.getElementById("announcementPopup").style.display = "block";
                document.getElementById("announcementOverlay").style.display = "block";

                function closeAnnouncementPopup() {
                  document.getElementById("announcementPopup").style.display = "none";
                  document.getElementById("announcementOverlay").style.display = "none";
                }
              </script>
            <?php endif; ?>


            <script>
              const openPopup = document.getElementById("openPopup");
              const closePopup = document.getElementById("closePopup");
              const overlay = document.getElementById("overlay");
              const popup = document.getElementById("popup");

              openPopup.addEventListener("click", () => {
                popup.classList.add("active");
                overlay.classList.add("active");
              });

              closePopup.addEventListener("click", () => {
                popup.classList.remove("active");
                overlay.classList.remove("active");
              });

              document.getElementById("submitForm").addEventListener("click", () => {
                const title = document.getElementById("title").value;
                const description = document.getElementById("description").value;
                const category = document.getElementById("category").value;
                const image = document.getElementById("image").files[0];

                console.log("Title:", title);
                console.log("Description:", description);
                console.log("Category:", category);
                console.log("Image:", image ? image.name : "No file selected");

                popup.classList.remove("active");
                overlay.classList.remove("active");
              });
            </script>
          </div>
        </div>


      </div>

    </div>

  </section>

</body>

</html>