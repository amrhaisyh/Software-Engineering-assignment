<?php
include "config.php";

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Delete query
    $sql = "DELETE FROM announcement WHERE announcementID = $id";

    // Execute query
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('The selected announcement has been deleted!');</script>";
        echo "<script>window.location.href = 'admin-configure-announcement.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close connection
    $conn->close();
}
