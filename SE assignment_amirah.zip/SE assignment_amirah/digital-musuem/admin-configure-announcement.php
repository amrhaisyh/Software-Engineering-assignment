<?php
include "config.php";

if (isset($_POST['submit'])) {
    // Get form data
    $title = $_POST['title'];
    $description = $_POST['description'];
    $datetime = $_POST['datetime'];

    // Insert query
    $sql = "INSERT INTO announcement (title, description, datetime) VALUES ('$title', '$description', '$datetime')";

    // Execute query
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('New Announcement has been added!');</script>";
        echo "<script>window.location.href = 'admin-configure-announcement.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the connection
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="icon" type="image/png" href="assets/logo-title.jpg" />
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet">
    <title>National Art Museum</title>
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
        }

        .bground-blue {
            background-color: #0097B2;
        }

        .sblue {
            color: #0097B2;
        }

        /* Style the progress bar fill */
        progress::-webkit-progress-value {
            background-color: #0097B2;
            /* Change the fill color to green */
        }

        .popup {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.4);
            width: 400px;
            /* Increased size */
            max-width: 90%;
        }

        .popup.active {
            display: block;
        }

        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            /* Darker transparency */
            backdrop-filter: blur(5px);
            /* Adds a slight blur effect */
        }

        .overlay.active {
            display: block;
        }

        .popup input,
        .popup textarea,
        .popup select {
            width: 100%;
            margin: 8px 0;
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .popup button {
            margin-top: 15px;
            padding: 10px;
            width: 100%;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-submit {
            background: #007bff;
            color: white;
        }

        .btn-cancel {
            background: #ccc;
            margin-top: 5px;
        }
    </style>
</head>

<body class="bg-slate-200">



    <section class="relative">
        <nav class="bg-white flex flex-row gap-x-5 shadow-xl py-3 px-10">
            <div class="flex gap-x-4  ml-5">
                <img style="height: 80px;" src="assets/logo-museum.png" alt="">
                <h1 class="sblue font-bold text-2xl my-auto">National Art Museum</h1>
            </div>
        </nav>
    </section>

    <section class="flex p-10 gap-x-5 h-full">
        <div class="w-[250px]">
            <div class="flex flex-col bg-white p-5 rounded-2xl">
                <svg class="w-20 mx-auto" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                    <path
                        d="M399 384.2C376.9 345.8 335.4 320 288 320H224c-47.4 0-88.9 25.8-111 64.2c35.2 39.2 86.2 63.8 143 63.8s107.8-24.7 143-63.8zM0 256a256 256 0 1 1 512 0A256 256 0 1 1 0 256zm256 16a72 72 0 1 0 0-144 72 72 0 1 0 0 144z" />
                </svg>
                <h1 class="text-lg  text-center mt-5">
                    <?php echo $_SESSION['role']; ?>
                </h1>
                <h1 class="text-sm  text-center">
                    <?php echo $_SESSION['name']; ?>
                </h1>
                <hr class="border-1 border-black my-5">
                <a class="flex mb-4" href="admin-exhibits.php">
                    <div class="w-10 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Exhibit</h1>
                </a>
                <a class="flex mb-4" href="admin-event.php">
                    <div class="w-9 ml-0.5 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Event</h1>
                </a>
                <a class="flex mb-4" href="admin-inquiries.php">
                    <div class="w-9 ml-0.5 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Inquiries</h1>
                </a>
                <a class="flex mb-4" href="admin-visitors.php">
                    <div class="w-9 ml-0.5 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Visitor</h1>
                </a>
                <?php
                if (isset($_SESSION['adminID']) && isset($_SESSION['role']) && $_SESSION['role'] == 'Admin') {
                    echo '
                    <a class="flex mb-4" href="admin-staff.php">
                        <div class="w-9 ml-0.5 mr-auto my-auto"></div>
                        <h1 class="w-full">Staff</h1>
                    </a>';
                }
                ?>
                <a class="flex mb-4" href="admin-feedback.php">
                    <div class="w-9 ml-0.5 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Feedback</h1>
                </a>
                <a class="flex mb-32" href="admin-summary.php">
                    <div class="w-9 ml-1 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Summary</h1>
                </a>
                <hr class="border-1 border-black my-5">
                <a class="flex mb-3" href="admin-profile.php">
                    <div class="w-9 ml-1 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Profile</h1>
                </a>
                <?php
                if (isset($_SESSION['adminID']) && isset($_SESSION['role']) && $_SESSION['role'] == 'Admin') {
                    echo '
                    <a class="flex mb-3  sblue font-semibold" href="admin-access.php">
                        <div class="w-9 ml-1 mr-auto my-auto">
                        </div>
                        <h1 class="w-full">Configuration</h1>
                    </a>
                    ';
                }
                ?>
                <a class="flex mb-10" href="logout.php">
                    <div class="w-9 ml-1 mr-auto my-auto">
                    </div>
                    <h1 class="w-full">Log Out</h1>
                </a>

            </div>

        </div>
        <div class="w-full h-full">
            <div class="bg-white rounded-2xl h-full">
                <div class="flex">
                    <h1 class="text-2xl font-semibold p-5">Announcement Details</h1>
                    <button style="background-color: #0097B2;" id="openPopup"
                        class="bg-blue text-white rounded-xl py-2 px-5 my-auto text-sm">ADD
                        ANNOUNCEMENT</button>

                </div>
                <hr class="border-gray-300 mb-6">
                <div class=" p-5 ">
                    <table class="w-full mt-5 border-collapse">
                        <thead>
                            <tr class="bg-gray-200">
                                <th class="p-2 text-s">No</th>
                                <th class="p-2 text-s">Title</th>
                                <th class="p-2 text-s">Description</th>
                                <th class="p-2 text-s">Date</th>
                                <th class="p-2 text-s">Time</th>
                                <th class="p-2 text-s">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- PHP - Fetch Data -->
                            <?php
                            $sql = "SELECT * FROM announcement;";
                            $result = mysqli_query($conn, $sql);

                            $count = 1;
                            if ($result && mysqli_num_rows($result) > 0) {
                                while ($row = mysqli_fetch_assoc($result)) {
                                    // Split datetime into date and time
                                    $datetime = new DateTime($row['datetime']);
                                    $formattedDate = $datetime->format('d/m/Y'); // Format: Day/Month/Year
                                    $formattedTime = $datetime->format('h:i A'); // Format: 12-hour format with AM/PM

                                    echo '
                                        <tr class="bg-white">
                                            <td class="p-2 border text-s text-center">' . $count . '</td>
                                            <td class="p-2 border text-s text-center">' . htmlspecialchars($row['title']) . '</td>
                                            <td class="p-2 border text-s text-center">' . htmlspecialchars($row['description']) . '</td>
                                            <td class="p-2 border text-s text-center">' . $formattedDate . '</td>
                                            <td class="p-2 border text-s text-center">' . $formattedTime . '</td>
                                            <td class="p-4 border text-s text-center">
                                                <a href="admin-delete-announcement.php?id=' . $row['announcementID'] . '" 
                                                class="bg-red-500 text-white px-4 py-2 rounded text-center" 
                                                onclick="return confirm(\'Are you sure you want to delete this announcement?\');">
                                                <span style="font-size:15px">Delete</span>
                                                </a>
                                            </td>
                                        </tr>';
                                    $count++;
                                }
                            } else {
                                echo '<tr><td colspan="6" class="text-center">No records found.</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <div class="overlay" id="overlay"></div>

                <div class="popup" id="popup">
                    <div class="popup-content">
                        <h2>Add New Announcement</h2>
                        <form action="" method="POST">
                            <input type="text" name="title" placeholder="Title" required>
                            <textarea name="description" placeholder="Description" required></textarea>
                            <input type="datetime-local" name="datetime" placeholder="Date and Time" required>
                            <button type="submit" class="btn-submit" name="submit">Submit</button>
                            <button type="button" id="closePopup" class="btn-cancel">Cancel</button>
                        </form>
                    </div>
                </div>

            </div>
            <script>
                // Get modal and button elements
                const openPopupButton = document.getElementById("openPopup"); // Ensure this matches the button ID
                const closePopupButton = document.getElementById("closePopup"); // Ensure this matches the button ID
                const popup = document.getElementById("popup");
                const overlay = document.getElementById("overlay");

                // Show the modal when "Add Announcement" button is clicked
                openPopupButton.addEventListener('click', function() {
                    popup.classList.add('active'); // Use 'active' to show the popup
                    overlay.classList.add("active");

                });

                // Hide the modal when "Cancel" button is clicked
                closePopupButton.addEventListener('click', function() {
                    popup.classList.remove('active'); // Remove 'active' to hide the popup
                    overlay.classList.remove("active");

                });

                // Hide the modal when clicked outside of the modal content
                window.addEventListener('click', function(e) {
                    if (e.target === popup) {
                        popup.classList.remove('active'); // Close the popup if clicked outside
                        overlay.classList.remove("active");

                    }
                });
            </script>
        </div>

    </section>

</body>

</html>